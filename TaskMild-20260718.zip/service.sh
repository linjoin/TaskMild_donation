#!/system/bin/sh

set -u

readonly MODDIR="${0%/*}"
readonly WORKDIR="/data/adb/taskmild"
readonly BINDIR="$WORKDIR/bin"
readonly BIN="$BINDIR/taskmild"
readonly CONFIG_DIR="$WORKDIR/config"
readonly LOCK_DIR="$WORKDIR/lock"
readonly LOGS_DIR="$WORKDIR/logs"
readonly DATA_DIR="$WORKDIR/data"
readonly PID_FILE="$LOCK_DIR/taskmild.pid"
readonly CONF="$CONFIG_DIR/taskmild.conf"
readonly MODULE_CONF="$MODDIR/payload/taskmild.conf"
readonly PANIC_FLAG="$DATA_DIR/panic_flag"
readonly STOP_MARKER="$DATA_DIR/stop_marker"
readonly LOG_FILE="$LOGS_DIR/run.log"
readonly CRASH_FILE="$DATA_DIR/crash_count"
readonly CRASH_DAY_FILE="$DATA_DIR/crash_day"
readonly INITIAL_BACKOFF=5
readonly MAX_BACKOFF=300
readonly MAX_DAILY_CRASHES=50
readonly MAX_CONSECUTIVE_FAILS=10
readonly DAEMON_STARTUP_SECS=1
readonly DAEMON_RETRY_SECS=1
readonly PANIC_WAIT_SECS=10
readonly HEALTH_CHECK_SECS=5
readonly INPUT_TIMEOUT_SECS=60
BACKOFF=$INITIAL_BACKOFF
CONSECUTIVE_FAILS=0
DAEMON_PID=""

log_info() {
    printf '[%s] [信息] %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$1" >> "$LOG_FILE" 2>/dev/null || true
}

log_warn() {
    printf '[%s] [警告] %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$1" >> "$LOG_FILE" 2>/dev/null || true
}

log_error() {
    printf '[%s] [错误] %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$1" >> "$LOG_FILE" 2>/dev/null || true
}

read_cfg() {
    if [ -f "$CONF" ]; then
        sed -n "s/^$1=//p" "$CONF" 2>/dev/null | head -n 1
    fi
}

ensure_config() {
    mkdir -p "$CONFIG_DIR" "$LOCK_DIR" "$LOGS_DIR" "$DATA_DIR" "$BINDIR" 2>/dev/null || true
    if [ ! -f "$CONF" ]; then
        if [ -f "$MODULE_CONF" ]; then
            cp -af "$MODULE_CONF" "$CONF"
        else
            log_error "模块默认配置 $MODULE_CONF 不存在"
        fi
    fi
    if [ ! -f "$CONFIG_DIR/Cleanup_Whitelist.txt" ]; then
        printf '# 清理白名单 (一行一条规则)\n# 支持: /path /path/ /path/* com.app.pkg\n' > "$CONFIG_DIR/Cleanup_Whitelist.txt" 2>/dev/null || true
    fi
    if [ ! -f "$CONFIG_DIR/Cleanup_Blacklist.txt" ]; then
        printf '# 清理黑名单 (一行一条规则)\n# 支持: /path /path/ /path/* pkg:com.app empty:/path gc:N\n' > "$CONFIG_DIR/Cleanup_Blacklist.txt" 2>/dev/null || true
    fi
}

reset_description_pending() {
    _prop="$MODDIR/module.prop"
    [ -f "$_prop" ] || return 0
    _tmp="$_prop.tmp"
    if awk -v desc='description=等待验证中' '
        BEGIN { found=0 }
        /^description=/ { print desc; found=1; next }
        { print }
        END { if (!found) print desc }
    ' "$_prop" > "$_tmp" 2>/dev/null; then
        mv -f "$_tmp" "$_prop" 2>/dev/null || true
    else
        rm -f "$_tmp" 2>/dev/null || true
    fi
}

rotate_log_on_boot() {
    if [ -f "$LOG_FILE" ]; then
        log_size=$(stat -c %s "$LOG_FILE" 2>/dev/null || echo 0)
        if [ "$log_size" -gt 0 ]; then
            boot_ts=$(date '+%Y%m%d_%H%M%S')
            cp -f "$LOG_FILE" "${LOG_FILE%.log}_${boot_ts}.log" 2>/dev/null || true
            cp -f "$LOG_FILE" "${LOG_FILE}.old" 2>/dev/null || true
            old_count=$(ls -1 "${LOG_FILE%.log}"_*.log 2>/dev/null | wc -l)
            if [ "$old_count" -gt 5 ]; then
                ls -1t "${LOG_FILE%.log}"_*.log 2>/dev/null | tail -n +6 | xargs rm -f 2>/dev/null || true
            fi
        fi
        printf '' > "$LOG_FILE" 2>/dev/null || true
    else
        touch "$LOG_FILE" 2>/dev/null || true
    fi
}

wait_for_boot() {
    _boot_wait=0
    while [ "$(getprop sys.boot_completed)" != "1" ]; do
        sleep 1
        _boot_wait=$((_boot_wait + 1))
        if [ "$_boot_wait" -gt 120 ]; then
            log_warn "等待开机完成超时 (120s)"
            return 1
        fi
    done
    return 0
}

unfreeze_stale_cgroups() {
    if [ -d /sys/fs/cgroup ]; then
        for f in /sys/fs/cgroup/*/cgroup.freeze /sys/fs/cgroup/*/*/cgroup.freeze; do
            [ -f "$f" ] || continue
            [ "$(cat "$f" 2>/dev/null)" = "1" ] || continue
            echo "0" > "$f" 2>/dev/null || true
            log_info "清理残留冻结 cgroup: ${f%/cgroup.freeze}"
        done
    fi
}

check_process_running() {
    [ -f "$PID_FILE" ] || return 1
    pid=$(cat "$PID_FILE" 2>/dev/null) || true
    [ -z "$pid" ] && return 1
    [ -d "/proc/$pid" ] || return 1
    if [ -f "/proc/$pid/cmdline" ]; then
        cmdline=$(cat "/proc/$pid/cmdline" 2>/dev/null | tr '\0' ' ') || true
        case "$cmdline" in
            *taskmild*|*Taskmild*) return 0 ;;
        esac
    fi
    return 1
}

record_crash() {
    count=$(cat "$CRASH_FILE" 2>/dev/null || printf '0')
    count=$((count + 1))
    printf '%s\n' "$count" > "$CRASH_FILE" || true
    if [ "$count" -ge "$MAX_DAILY_CRASHES" ]; then
        log_warn "TaskMild 频繁崩溃 (今日第${count}次)"
    fi
}

reset_daily_crash_count() {
    current_day=$(date '+%Y%m%d')
    last_reset_day=$(cat "$CRASH_DAY_FILE" 2>/dev/null || printf '')
    if [ "$current_day" != "$last_reset_day" ]; then
        printf '0\n' > "$CRASH_FILE" || true
        printf '%s\n' "$current_day" > "$CRASH_DAY_FILE" || true
    fi
}

start_daemon() {
    [ -x "$BIN" ] || {
        log_error "TaskMild 二进制文件不存在"
        return 1
    }
    check_process_running && return 0
    if [ -f "$PANIC_FLAG" ]; then
        panic_msg=$(cat "$PANIC_FLAG" 2>/dev/null) || true
        rm -f "$PANIC_FLAG" || true
        log_warn "检测到 panic 标记: ${panic_msg}，等待${PANIC_WAIT_SECS}秒后重启"
        sleep "$PANIC_WAIT_SECS"
    fi
    "$BIN" run >>"$LOG_FILE" 2>/dev/null &
    DAEMON_PID=$!
    sleep "$DAEMON_STARTUP_SECS"
    if check_process_running; then
        pid=$(cat "$PID_FILE" 2>/dev/null) || true
        log_info "TaskMild 启动成功 PID=${pid}"
        return 0
    fi
    sleep "$DAEMON_RETRY_SECS"
    if check_process_running; then
        pid=$(cat "$PID_FILE" 2>/dev/null) || true
        log_info "TaskMild 启动成功 PID=${pid}"
        return 0
    fi
    wait "$DAEMON_PID" 2>/dev/null || true
    exit_code=$?
    log_error "TaskMild 启动失败 (退出码=${exit_code})"
    DAEMON_PID=""
    return 1
}

run_swap_extras() {
    _swap_en=$(read_cfg swap_enable)
    [ -z "$_swap_en" ] && _swap_en="on"
    [ "$_swap_en" != "on" ] && return

    if [ -f "$MODDIR/scripts/service.dex" ] && [ -f "$MODDIR/scripts/extra.sh" ]; then
        sh "$MODDIR/scripts/extra.sh"
    fi

    _busybox=""
    for _bb in /data/adb/magisk/busybox /data/adb/ksu/bin/busybox /data/adb/ap/bin/busybox; do
        if [ -x "$_bb" ]; then
            _busybox="$_bb"
            break
        fi
    done
    if [ -n "$_busybox" ]; then
        "$_busybox" fstrim /data 2>/dev/null || true
        "$_busybox" fstrim /cache 2>/dev/null || true
    fi
}

check_screen_on() {
    for sp in /sys/class/backlight/*/bl_power /sys/class/graphics/fb0/blank; do
        if [ -f "$sp" ]; then
            val=$(cat "$sp" 2>/dev/null || echo "")
            case "$val" in
                0) return 0 ;;
            esac
        fi
    done
    for sp in /sys/class/drm/card*/card*/dpms; do
        if [ -f "$sp" ]; then
            val=$(cat "$sp" 2>/dev/null || echo "")
            case "$val" in
                On|on|0) return 0 ;;
            esac
        fi
    done
    _sp="/sys/class/display/power"
    if [ -f "$_sp" ]; then
        val=$(cat "$_sp" 2>/dev/null || echo "")
        case "$val" in
            on|On|0) return 0 ;;
        esac
    fi
    return 1
}

check_unlocked() {
    if [ -f /dev/cpuset/top-app/cgroup.procs ]; then
        topapp_pids=$(cat /dev/cpuset/top-app/cgroup.procs 2>/dev/null | grep -v '^$' | head -n 1)
        [ -n "$topapp_pids" ] && return 0
    fi
    if [ -f /sys/fs/cgroup/top-app/cgroup.procs ]; then
        topapp_pids=$(cat /sys/fs/cgroup/top-app/cgroup.procs 2>/dev/null | grep -v '^$' | head -n 1)
        [ -n "$topapp_pids" ] && return 0
    fi

    for pid_dir in /proc/[0-9]*; do
        [ -f "$pid_dir/oom_score_adj" ] || continue
        oom=$(cat "$pid_dir/oom_score_adj" 2>/dev/null)
        if [ "$oom" = "0" ]; then
            [ -f "$pid_dir/cmdline" ] || continue
            cmdline=$(cat "$pid_dir/cmdline" 2>/dev/null | tr '\0' ' ')
            case "$cmdline" in
                system_server|surfaceflinger|zygote*) continue ;;
            esac
            case "$cmdline" in
                *.*.* ) return 0 ;;
            esac
        fi
    done

    return 1
}

wait_for_input_event() {
    if check_screen_on && check_unlocked; then
        return 0
    fi

    touchscreen_dev=""
    for event_path in /dev/input/event*; do
        [ -e "$event_path" ] || continue
        event_num="${event_path##*/event}"
        if [ -d "/sys/class/input/event${event_num}/device" ]; then
            dev_name=$(cat "/sys/class/input/event${event_num}/device/name" 2>/dev/null) || true
            case "$dev_name" in
                *[Tt]ouch*|*[Tt]s*|*[Ff]inger*|*[Mm]t-*|*synaptics*|*goodix*|*focaltech*|*atmel*|*himax*|*ilitek*|*cyttsp*|*ft5*|*gt*|*msg*)
                    touchscreen_dev="$event_path"
                    break
                    ;;
            esac
        fi
    done

    if ! command -v getevent >/dev/null 2>&1; then
        log_warn "getevent 不可用，使用屏幕状态轮询替代"
        remaining=$INPUT_TIMEOUT_SECS
        while [ "$remaining" -gt 0 ]; do
            if check_screen_on && check_unlocked; then
                return 0
            fi
            sleep 3
            remaining=$((remaining - 3))
        done
        log_warn "屏幕状态轮询超时(${INPUT_TIMEOUT_SECS}s)，强制启动"
        return 0
    fi

    has_timeout=false
    if command -v timeout >/dev/null 2>&1; then
        has_timeout=true
    fi

    remaining=$INPUT_TIMEOUT_SECS
    while [ "$remaining" -gt 0 ]; do
        wait_secs=3
        if [ "$remaining" -lt "$wait_secs" ]; then
            wait_secs=$remaining
        fi

        event_detected=false

        if [ "$has_timeout" = "true" ]; then
            if [ -n "$touchscreen_dev" ]; then
                timeout "$wait_secs" getevent -c 1 "$touchscreen_dev" >/dev/null 2>&1
            else
                timeout "$wait_secs" getevent -c 1 >/dev/null 2>&1
            fi
            exit_code=$?
            if [ "$exit_code" -eq 0 ]; then
                event_detected=true
            fi
        else
            if [ -n "$touchscreen_dev" ]; then
                getevent -c 1 "$touchscreen_dev" >/dev/null 2>&1 &
            else
                getevent -c 1 >/dev/null 2>&1 &
            fi
            gev_pid=$!
            sleep "$wait_secs"
            if kill -0 "$gev_pid" 2>/dev/null; then
                kill "$gev_pid" 2>/dev/null
                wait "$gev_pid" 2>/dev/null
            else
                wait "$gev_pid" 2>/dev/null
                event_detected=true
            fi
        fi

        if [ "$event_detected" = "true" ]; then
            return 0
        fi

        if check_screen_on; then
            sleep 1
            if check_unlocked; then
                return 0
            fi
        fi

        remaining=$((remaining - wait_secs))
    done

    log_warn "等待input事件超时(${INPUT_TIMEOUT_SECS}s)，强制启动"
    return 0
}

is_mtk_new() {
    _platform=$(getprop ro.board.platform 2>/dev/null)
    case "$_platform" in
        mt6*) return 0 ;;
    esac
    _soc=$(getprop ro.soc.model 2>/dev/null)
    case "$_soc" in
        MT6*) return 0 ;;
    esac
    _kv=$(uname -r 2>/dev/null | cut -d'.' -f1)
    if [ "$_kv" -ge 5 ] && [ -f /proc/psi ]; then
        _hw=$(getprop ro.hardware 2>/dev/null | tr '[:upper:]' '[:lower:]')
        case "$_hw" in
            mt6*) return 0 ;;
        esac
    fi
    return 1
}

is_xiaomi() {
    [ -n "$(getprop ro.miui.ui.version.name 2>/dev/null)" ] && return 0
    _brand=$(getprop ro.product.brand 2>/dev/null | tr '[:upper:]' '[:lower:]')
    [ "$_brand" = "xiaomi" ] && return 0
    _mfr=$(getprop ro.product.manufacturer 2>/dev/null | tr '[:upper:]' '[:lower:]')
    [ "$_mfr" = "xiaomi" ] && return 0
    return 1
}

is_oppo() {
    _brand=$(getprop ro.product.brand 2>/dev/null | tr '[:upper:]' '[:lower:]')
    case "$_brand" in
        oppo|oneplus|realme) return 0 ;;
    esac
    [ -n "$(getprop persist.sys.oplus.confirm 2>/dev/null)" ] && return 0
    [ -d /sys/kernel/mm/athena ] && return 0
    return 1
}

is_qualcomm_kona() {
    _platform=$(getprop ro.board.platform 2>/dev/null)
    case "$_platform" in
        kona|lahaina|shima|taro|cape|parrot|diwali|ukee) return 0 ;;
    esac
    _soc=$(getprop ro.soc.model 2>/dev/null)
    case "$_soc" in
        SM8250|SM8350|SM8450|SM8475|SM8550|SM8650) return 0 ;;
    esac
    return 1
}

run_oem_adaptations() {
    _swap_en=$(read_cfg swap_enable)
    [ -z "$_swap_en" ] && _swap_en="on"
    [ "$_swap_en" != "on" ] && return

    if is_mtk_new; then
        setprop persist.vendor.psi.enable true 2>/dev/null || true
    fi

    if is_xiaomi; then
        if [ -f "$MODDIR/specific/xiaomi/tuning.sh" ]; then
            sh "$MODDIR/specific/xiaomi/tuning.sh" 2>/dev/null || true
        else
            for f in /sys/module/mi_thermald/parameters/*; do
                if [ -f "$f" ]; then
                    bn=$(basename "$f")
                    case "$bn" in
                        enabled) echo 0 > "$f" 2>/dev/null ;;
                    esac
                fi
            done
            if [ -d /sys/kernel/mm/athena ]; then
                echo 0 > /sys/kernel/mm/athena/enable 2>/dev/null
            fi
        fi
        pkill -9 mi_thermald 2>/dev/null || true
    fi

    if is_oppo; then
        if [ -f "$MODDIR/specific/oppo/tuning.sh" ]; then
            sh "$MODDIR/specific/oppo/tuning.sh" 2>/dev/null || true
        fi
    fi

    if is_qualcomm_kona; then
        if [ -f "$MODDIR/specific/qualcomm/tuning.sh" ]; then
            sh "$MODDIR/specific/qualcomm/tuning.sh" 2>/dev/null || true
        fi
    fi
}

wait_for_boot
unfreeze_stale_cgroups
rotate_log_on_boot
ensure_config
reset_description_pending

sync_thermal_override() {
    _toggle="$MODDIR/scripts/tools.thermal-toggle.sh"
    [ -x "$_toggle" ] || return 0
    _out=$("$_toggle" --apply 2>/dev/null) || true
    _status=$("$_toggle" --status 2>/dev/null) || true
    case "$_status" in
        *一致*) ;;
        *) log_info "温控屏蔽: 开机同步 - $_status" ;;
    esac
}
sync_thermal_override

rm -f "$STOP_MARKER" 2>/dev/null || true

wait_for_input_event

run_oem_adaptations

SERVICE_LOCK="$LOCK_DIR/taskmild.sh.lock"
if command -v flock >/dev/null 2>&1; then
    exec 200>"$SERVICE_LOCK" 2>/dev/null || true
    if ! flock -n 200 2>/dev/null; then
        log_warn "taskmild service 已在运行, 退出本次启动"
        exit 0
    fi
else
    if ! mkdir "$SERVICE_LOCK" 2>/dev/null; then
        log_warn "taskmild service 已在运行, 退出本次启动"
        exit 0
    fi
    trap 'rmdir "$SERVICE_LOCK" 2>/dev/null || true' EXIT INT TERM
fi

run_swap_extras &
start_daemon

while true; do
    if [ -n "$DAEMON_PID" ]; then
        wait "$DAEMON_PID" 2>/dev/null || true
        DAEMON_PID=""
    else
        if check_process_running; then
            sleep "$HEALTH_CHECK_SECS"
            continue
        fi
    fi
    if [ -f "$STOP_MARKER" ]; then
        marker_content=$(cat "$STOP_MARKER" 2>/dev/null || echo "")
        if [ "$marker_content" = "auth_exhausted" ]; then
            log_error "验证重试次数已耗尽，停止重启"
            exit 0
        fi
        rm -f "$STOP_MARKER" || true
        exit 0
    fi
    reset_daily_crash_count
    auth_fail_count=$(head -n1 "$DATA_DIR/auth_fail_count" 2>/dev/null || echo "0")
    auth_fail_count=$(echo "$auth_fail_count" | grep -oE '^[0-9]+' || echo "0")
    if [ "$auth_fail_count" -ge 9 ]; then
        log_error "验证连续失败 ${auth_fail_count} 次，已达上限"
        echo "auth_exhausted" > "$STOP_MARKER"
        exit 0
    fi
    log_warn "TaskMild 进程退出，尝试重启 (退避=${BACKOFF}s)"
    if ! start_daemon; then
        CONSECUTIVE_FAILS=$((CONSECUTIVE_FAILS + 1))
        record_crash
        if [ "$CONSECUTIVE_FAILS" -gt "$MAX_CONSECUTIVE_FAILS" ]; then
            BACKOFF=$MAX_BACKOFF
        else
            BACKOFF=$((BACKOFF * 2))
            [ "$BACKOFF" -gt "$MAX_BACKOFF" ] && BACKOFF=$MAX_BACKOFF
        fi
        sleep "$BACKOFF"
    else
        BACKOFF=$INITIAL_BACKOFF
        CONSECUTIVE_FAILS=0
    fi
done
