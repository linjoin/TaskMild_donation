#!/system/bin/sh

readonly WORKDIR="/data/adb/taskmild"
readonly MODDIR="/data/adb/modules/taskmild"
readonly CONFIG_DIR="$WORKDIR/config"
readonly LOCK_DIR="$WORKDIR/lock"
readonly LOGS_DIR="$WORKDIR/logs"
readonly DATA_DIR="$WORKDIR/data"
readonly PID_FILE="$LOCK_DIR/taskmild.pid"
readonly LOG_FILE="$LOGS_DIR/run.log"
readonly STOP_MARKER="$DATA_DIR/stop_marker"
readonly AUTH_FAIL_COUNT="$DATA_DIR/auth_fail_count"
readonly LOCK_FILE="$LOCK_DIR/taskmild.lock"
readonly CRASH_COUNT="$DATA_DIR/crash_count"
readonly CRASH_DAY="$DATA_DIR/crash_day"
readonly PANIC_FLAG="$DATA_DIR/panic_flag"

touch "$STOP_MARKER" 2>/dev/null || true

stop_all_processes() {
    killall -9 taskmild 2>/dev/null || true
    pkill -9 -f 'taskmild.*service\.sh' 2>/dev/null || true
    sleep 0.5
}

cleanup_workdir() {
    rm -f "$PID_FILE" 2>/dev/null || true
    rm -f "$LOCK_FILE" 2>/dev/null || true
    rm -f "$LOG_FILE" 2>/dev/null || true
    rm -f "$LOGS_DIR"/run.log.* 2>/dev/null || true
    rm -f "$LOGS_DIR"/thermal_bind.log 2>/dev/null || true
    rm -f "$LOCK_DIR"/purge_blacklist.cache 2>/dev/null || true
    rm -f "$LOCK_DIR"/purge_whitelist.cache 2>/dev/null || true
    rm -f "$AUTH_FAIL_COUNT" 2>/dev/null || true
    rm -f "${AUTH_FAIL_COUNT}.lock" 2>/dev/null || true
    rm -f "$CRASH_COUNT" 2>/dev/null || true
    rm -f "$CRASH_DAY" 2>/dev/null || true
    rm -f "$PANIC_FLAG" 2>/dev/null || true
    rm -f "$DATA_DIR/stats.txt" 2>/dev/null || true
    rm -f "$DATA_DIR/license_agreed" 2>/dev/null || true
    rm -f "$DATA_DIR/thermal_mounts.list" 2>/dev/null || true
    rm -f "$WORKDIR/bin/taskmild.pid" 2>/dev/null || true
    rm -f "$WORKDIR/bin/taskmild.lock" 2>/dev/null || true
    rm -f "$WORKDIR/run.log" "$WORKDIR/run.log.1" 2>/dev/null || true
    rm -f "$WORKDIR/purge_blacklist.cache" "$WORKDIR/purge_whitelist.cache" 2>/dev/null || true
    rm -f "$WORKDIR/lock" 2>/dev/null || true
    rm -f "$WORKDIR/stop_marker" "$WORKDIR/auth_fail_count" "$WORKDIR/auth_fail_count.lock" 2>/dev/null || true
    rm -f "$WORKDIR/crash_count" "$WORKDIR/crash_day" "$WORKDIR/panic_flag" 2>/dev/null || true
    rm -f "$WORKDIR/stats.txt" "$WORKDIR/purge_stats" 2>/dev/null || true
    rm -f "$WORKDIR/license_agreed" 2>/dev/null || true
    rm -f "$WORKDIR/thermal_mounts.list" "$WORKDIR/thermal_bind.log" 2>/dev/null || true
    rmdir "$LOCK_DIR" 2>/dev/null || true
    rmdir "$LOGS_DIR" 2>/dev/null || true
    rmdir "$DATA_DIR" 2>/dev/null || true
}

cleanup_moddir() {
    rm -rf "$MODDIR" 2>/dev/null || true
}

stop_all_processes
cleanup_workdir
cleanup_moddir
