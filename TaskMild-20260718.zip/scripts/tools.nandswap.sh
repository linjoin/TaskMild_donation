#!/system/bin/sh

MODDIR=${0%/*}
MODDIR=$(readlink -f "$MODDIR" 2>/dev/null || echo "$MODDIR")

. "$MODDIR/tools.sh"

BLK_OPLUS='/sys/block/zram0/hybridswap_loop_device'
BLK_MEIZU='/sys/block/zram0/smartswap_loop_device'
readonly HYBRID_SWAP_CORE="/sys/block/zram0/hybridswap_core_enable"
readonly SMART_SWAP_CORE="/sys/block/zram0/smartswap_core_enable"
readonly NST='/product/bin/nandswap_tool'
readonly SZT='/vendor/bin/smartzram_tool'
readonly BLK_OPLUS_CRYPTO='/dev/block/mapper/hybridswap_crypto'
readonly EXTM_FILES="/data/extm/extm_file /data/nandswap/swapfile /data/vendor/swap/zram /data/writeback"

if [ -f /data/adb/ap/bin/losetup ]; then
    alias losetup='/data/adb/ap/bin/losetup'
elif [ -f /system/bin/losetup ]; then
    alias losetup='/system/bin/losetup'
fi

nandswap_supported() {
    if [ -e "$HYBRID_SWAP_CORE" ] && [ -e "$NST" ]; then
        if [ "$(kernel_compare "6.6")" -lt 0 ]; then
            if ! grep -q zram1 /proc/swaps 2>/dev/null; then
                if [ "$(cat /sys/block/zram0/hybridswap_loop_device 2>/dev/null)" != "chp" ]; then
                    return 0
                fi
            fi
        fi
    fi
    return 2
}

smartswap_supported() {
    if [ -e "$SMART_SWAP_CORE" ] && [ -e "$SZT" ]; then
        if [ "$(kernel_compare "6.6")" -lt 0 ]; then
            return 0
        fi
    fi
    return 2
}

disable_nandswap() {
    if nandswap_supported; then
        setprop persist.sys.oplus.nandswap false
        setprop persist.sys.oplus.nandswap.swapsize ''
        setprop persist.sys.oplus.nandswap.swapsize.curr ''
    fi
}

disable_smartswap() {
    if smartswap_supported; then
        setprop persist.vendor.meizu.smart_zram false
        setprop persist.vendor.meizu.smart_zram.swapsize ''
        setprop persist.vendor.meizu.smart_zram.swapsize.curr ''
    fi
}

release_nandswap() {
    if [ -f "$BLK_OPLUS" ]; then
        set_value 0 /sys/block/zram0/hybridswap_core_enable
        set_value 0 /sys/block/zram0/hybridswap_enable
        set_value 1 /sys/block/zram0/hybridswap_swapd_pause
        set_value 0 /sys/block/zram0/hybridswap_zram_increase
        set_value 'swapd_swappiness=0' /proc/oplus_mem/swappiness_para
        set_value '' "$BLK_OPLUS"
    fi
}

release_smartswap() {
    if [ -f "$BLK_MEIZU" ]; then
        set_value 0 /sys/block/zram0/smartswap_core_enable
        set_value 0 /sys/block/zram0/smartswap_enable
        set_value 1 /sys/block/zram0/smartswap_swapd_pause
        set_value 0 /sys/block/zram0/smartswap_zram_increase
        set_value '' "$BLK_MEIZU"
    fi
}

set_nandswap() {
    zram_increase=$1
    if [ -z "$zram_increase" ] || [ ! -f "$NST" ]; then
        return
    fi
    block_file=/data/writeback
    block_size=$((zram_increase / 2))
    if [ ! -f "$block_file" ]; then
        dd if=/dev/zero of="$block_file" bs=1M count="$block_size" 2>/dev/null
    fi
    loop_device=$(losetup -f 2>/dev/null)
    if [ -n "$loop_device" ]; then
        losetup "$loop_device" "$block_file" 2>/dev/null
        set_dio=$("$NST" -l "$loop_device" 2>/dev/null | awk '{print $2}')
        if [ "$set_dio" = "success" ]; then
            printf '%s' "$loop_device" > "$BLK_OPLUS"
            echo 1 > /sys/block/zram0/hybridswap_enable
            echo "$zram_increase" > /sys/block/zram0/hybridswap_zram_increase
            echo 21474836480 > /sys/block/zram0/hybridswap_quota_day
        else
            losetup -d "$loop_device" 2>/dev/null
            rm -f "$block_file"
        fi
    fi
}

set_smartswap() {
    zram_increase=$1
    if [ -z "$zram_increase" ] || [ ! -f "$SZT" ]; then
        return
    fi
    block_file=/data/writeback
    block_size=$((zram_increase / 2))
    if [ ! -f "$block_file" ]; then
        dd if=/dev/zero of="$block_file" bs=1M count="$block_size" 2>/dev/null
    fi
    loop_device=$(losetup -f 2>/dev/null)
    if [ -n "$loop_device" ]; then
        losetup "$loop_device" "$block_file" 2>/dev/null
        set_dio=$("$SZT" -l "$loop_device" 2>/dev/null | awk '{print $2}')
        if [ "$set_dio" = "success" ]; then
            printf '%s' "$loop_device" > "$BLK_MEIZU"
            echo 1 > /sys/block/zram0/smartswap_enable
            echo "$zram_increase" > /sys/block/zram0/smartswap_zram_increase
        else
            losetup -d "$loop_device" 2>/dev/null
            rm -f "$block_file"
        fi
    fi
}

writeback_supported() {
    if [ -f "/sys/block/zram0/backing_dev" ] && [ -f "/sys/block/zram0/writeback" ]; then
        if [ "$(kernel_compare "4.19")" -gt 0 ]; then
            return_true
            return
        fi
    fi
    return_false
}

extm_supported() {
    blk=""
    if [ -f "$BLK_OPLUS" ] && [ "$(kernel_compare "6.6")" -lt 0 ]; then
        blk=$BLK_OPLUS
    elif [ -f "$BLK_MEIZU" ] && [ "$(kernel_compare "6.6")" -lt 0 ]; then
        blk=$BLK_MEIZU
    elif [ -f "/sys/block/zram0/backing_dev" ] && [ -f "/sys/block/zram0/writeback" ]; then
        blk="/sys/block/zram0/backing_dev"
    else
        return_false
        return
    fi
    dev=$(cat "$blk" 2>/dev/null)
    if [ -z "$dev" ] || [ "$dev" = "chp" ] || [ "$dev" = "none" ]; then
        return_false
        return
    fi
    case "$dev" in
        *crypto*) return_false; return ;;
    esac
    return_true
}
