#!/system/bin/sh

MODDIR=${0%/*}
MODDIR=$(readlink -f "$MODDIR" 2>/dev/null || echo "$MODDIR")

update_update_list() {
    name="$1"
    xml="$2"
    if [ ! -f "$xml" ]; then
        return
    fi
    provider="content://com.oplus.romupdate.provider.db/update_list"
    version=$(date +%Y%m%d%H)
    values=$(cat "$xml")
    values=$(echo "$values" | sed "s|<filter-name>.*</filter-name>|<filter-name>$name</filter-name>|g")
    values=$(echo "$values" | sed "s|<version>.*</version>|<version>$version</version>|g")
    values=$(echo "$values" | sed 's/:/\\:/g')
    content delete --uri "$provider" --where "filterName='$name'" 2>/dev/null || true
    content insert --uri "$provider" \
        --bind filterName:s:"$name" \
        --bind version:s:"$version" \
        --bind xml:s:"$values" \
        --bind isOpen:i:1 2>/dev/null || true
}

patch_update_list() {
    clear_update_list
    sync && sleep 2
    rom_update_db=/data/user_de/0/com.oplus.romupdate/databases/rom_update.db
    if [ -f "$rom_update_db" ]; then
        cp -pf "$rom_update_db" "$rom_update_db.bak" 2>/dev/null || true
    fi
    if [ -z "$MODPATH" ]; then
        MODPATH="/data/adb/modules/taskmild"
    fi
    patched="$MODPATH/athena"
    if [ -d "$patched" ]; then
        update_update_list "sys_athena_custom_config_list" "$patched/sys_athena_custom_config_list.xml"
        update_update_list "sys_custom_clear_config" "$patched/sys_custom_clear_config.xml"
    fi
}

clear_update_list() {
    provider="content://com.oplus.romupdate.provider.db/update_list"
    content delete --uri "$provider" --where "filterName='sys_athena_custom_config_list'" 2>/dev/null || true
    content delete --uri "$provider" --where "filterName='sys_custom_clear_config'" 2>/dev/null || true
    content delete --uri "$provider" --where "filterName='sys_osense_common_config'" 2>/dev/null || true
}
