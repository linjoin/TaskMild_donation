#!/system/bin/sh

set +e

JSON_MODE=0
[ "$1" = "--json" ] && JSON_MODE=1

if [ "$(id -u 2>/dev/null || echo 1)" -ne 0 ]; then
    if [ "$JSON_MODE" = "1" ]; then
        echo '{"error":"需要 root 权限","code":2}'
    else
        echo "! 需要 root 权限执行"
    fi
    exit 2
fi

_self_ns=$(readlink /proc/self/ns/mnt 2>/dev/null || echo "")
_init_ns=$(readlink /proc/1/ns/mnt 2>/dev/null || echo "")
if [ -n "$_self_ns" ] && [ -n "$_init_ns" ] && [ "$_self_ns" != "$_init_ns" ]; then
    if command -v nsenter >/dev/null 2>&1 && [ -d /proc/1/ns/mnt ]; then
        exec nsenter -t 1 -m -- "$0" "$@"
    fi
fi

SCAN_DIRS="/system /vendor /product /system_ext"

get_size() {
    sz=$(stat -c %s "$1" 2>/dev/null) && [ -n "$sz" ] && { echo "$sz"; return; }
    sz=$(ls -s "$1" 2>/dev/null | awk '{print $1}') && [ -n "$sz" ] && { echo "$((sz*1024))"; return; }
    echo "0"
}

TMP_LIST=$(mktemp 2>/dev/null || echo /tmp/thermal_check_$$)
find $SCAN_DIRS -type f -iname "*thermal*" 2>/dev/null | grep -v '/hardware/' > "$TMP_LIST"

TOTAL=0
BLOCKED=0
LEAKED=0
SO_FILES=0

if [ "$JSON_MODE" = "1" ]; then
    json_escape() {
        printf '%s' "$1" | sed 's/\\/\\\\/g; s/"/\\"/g'
    }

    printf '{"items":['
    first=1
    while IFS= read -r f; do
        [ -z "$f" ] && continue
        TOTAL=$((TOTAL+1))
        sz=$(get_size "$f")
        base=$(basename "$f")
        case "$base" in
            *.so)
                SO_FILES=$((SO_FILES+1))
                status="skipped"
                ;;
            *)
                if [ "$sz" -eq 0 ]; then
                    BLOCKED=$((BLOCKED+1))
                    status="blocked"
                else
                    LEAKED=$((LEAKED+1))
                    status="leaked"
                fi
                ;;
        esac
        [ "$first" = "1" ] || printf ','
        first=0
        category="other"
        case "$base" in
            thermal-engine*) category="qcom-thermal-engine" ;;
            thermal_policy*|thermal-policy*) category="thermal-policy" ;;
            thermal-info*|thermal_info*) category="thermal-info" ;;
            mi_thermal*|mi-thermal*) category="xiaomi" ;;
            mz_thermal*) category="meizu" ;;
            thermald*) category="thermald" ;;
            thermal.conf|thermal*.conf) category="thermal-conf" ;;
            horae*) category="mediatek-horae" ;;
            *.rc) category="init-rc" ;;
            *.sql) category="obrain-sql" ;;
            *.json) category="json-config" ;;
            *.xml) category="xml-config" ;;
        esac
        printf '{"path":"%s","size":%s,"status":"%s","category":"%s"}' \
            "$(json_escape "$f")" "$sz" "$status" "$category"
    done < "$TMP_LIST"
    printf '],"summary":{"total":%s,"blocked":%s,"leaked":%s,"so_skipped":%s}}' \
        "$TOTAL" "$BLOCKED" "$LEAKED" "$SO_FILES"
    rm -f "$TMP_LIST" 2>/dev/null
    [ "$LEAKED" -gt 0 ] && exit 1
    exit 0
fi

echo
echo "==================== 温控屏蔽自检 ===================="
echo "  原作者: 酷安@御坂Thepoor  v1.3"
echo "  融合改造: TaskMild"
echo "======================================================"
echo
echo "扫描分区: $SCAN_DIRS"
echo "扫描中... (排除 /hardware/ 路径)"
echo

if [ ! -s "$TMP_LIST" ]; then
    echo "  未找到任何 thermal 文件 (系统可能已无温控或路径异常)"
    rm -f "$TMP_LIST" 2>/dev/null
    exit 0
fi

echo "------------------------------------------------------"
printf "  %-12s %s\n" "大小" "文件路径"
echo "------------------------------------------------------"

while IFS= read -r f; do
    [ -z "$f" ] && continue
    TOTAL=$((TOTAL+1))
    sz=$(get_size "$f")
    base=$(basename "$f")
    case "$base" in
        *.so)
            SO_FILES=$((SO_FILES+1))
            printf "  %-12s %s  [驱动, 跳过]\n" "${sz}B" "$f"
            ;;
        *)
            if [ "$sz" -eq 0 ]; then
                BLOCKED=$((BLOCKED+1))
                printf "  %-12s %s  [✓ 已屏蔽]\n" "0B" "$f"
            else
                LEAKED=$((LEAKED+1))
                printf "  %-12s %s  [✗ 未屏蔽!]\n" "${sz}B" "$f"
            fi
            ;;
    esac
done < "$TMP_LIST"

rm -f "$TMP_LIST" 2>/dev/null

echo "------------------------------------------------------"
echo
echo "  扫描总计: $TOTAL 个文件"
echo "    ✓ 已屏蔽: $BLOCKED"
echo "    ✗ 未屏蔽: $LEAKED  (漏网之鱼)"
echo "    ~ 驱动跳过: $SO_FILES  (.so 文件, 不影响性能释放)"
echo

if [ "$LEAKED" -gt 0 ]; then
    echo "  ! 发现 $LEAKED 个未屏蔽文件"
    echo "  ! 请检查 vendor/etc 下 thermal 开头的文件是否为 0 字节"
    echo "  ! 部分机型处理器特殊, 查询脚本误报但实际已屏蔽 (去 vendor/etc 确认)"
    echo "  ! 如确实未屏蔽, 可反馈给作者"
    exit 1
else
    echo "  ✓ 全部温控配置文件屏蔽成功"
    exit 0
fi
