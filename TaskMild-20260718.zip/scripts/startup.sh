#!/system/bin/sh

set -u

MODDIR=${0%/*}
MODDIR=$(readlink -f "$MODDIR" 2>/dev/null || echo "$MODDIR")

. "$MODDIR/tools.sh"
. "$MODDIR/tools.startup.sh"
. "$MODDIR/tools.nandswap.sh"

readonly SWAP_FILE='/data/swapfile'
LOG_FILE='/data/adb/taskmild/run.log'

log_info() {
    printf '[%s] [信息] %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$1" >> "$LOG_FILE" 2>/dev/null || true
}

log_warn() {
    printf '[%s] [警告] %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$1" >> "$LOG_FILE" 2>/dev/null || true
}

log_error() {
    printf '[%s] [错误] %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$1" >> "$LOG_FILE" 2>/dev/null || true
}

if [ -f /system/bin/swapon ]; then
    alias swapon='/system/bin/swapon'
    alias swapoff='/system/bin/swapoff'
    alias mkswap='/system/bin/mkswap'
elif [ -f /vendor/bin/swapon ]; then
    alias swapon='/vendor/bin/swapon'
    alias swapoff='/vendor/bin/swapoff'
    alias mkswap='/vendor/bin/mkswap'
fi
if [ -f /system/bin/dd ]; then
    alias dd='/system/bin/dd'
elif [ -f /vendor/bin/dd ]; then
    alias dd='/vendor/bin/dd'
fi

import_config

: "${zram:=false}"
: "${swap:=false}"
: "${zram_writeback:=false}"
: "${zram_size:=}"
: "${swap_size:=}"
: "${swap_priority:=}"
: "${comp_algorithm:=}"
: "${swappiness:=}"
: "${extra_free_kbytes:=}"
: "${watermark_scale_factor:=}"

compute_auto_zram_size() {
    _ram_gb=$MEM_TOTAL_GB
    _auto_size=$((_ram_gb * 1024 * 3 / 2))
    echo "$_auto_size"
}

if [ -z "$zram_size" ] || [ "$zram_size" = "auto" ] || [ "$zram_size" = "0" ]; then
    if [ "$zram" = "true" ]; then
        zram_size=$(compute_auto_zram_size)
        log_info "  ZRAM 大小: ${zram_size}MB (自动)"
    fi
else
    log_info "  ZRAM 大小: ${zram_size}MB (用户自定义)"
fi

if [ -z "$comp_algorithm" ] || [ "$comp_algorithm" = "auto" ]; then
    comp_algorithm="lz4"
    if [ -f /sys/block/zram0/comp_algorithm ]; then
        for alg in zstd zstdn lz4k lz4 lzo-rle lzo; do
            if grep -q "$alg" /sys/block/zram0/comp_algorithm 2>/dev/null; then
                comp_algorithm="$alg"
                break
            fi
        done
    fi
    log_info "  压缩算法: ${comp_algorithm} (自动选择)"
fi

set_swap() {
    if [ "$swap" = "true" ] && [ -n "$swap_size" ] && [ "$swap_size" != "0" ]; then
        if [ -f "$SWAP_FILE" ]; then
            file_size=$(stat -c %s "$SWAP_FILE" 2>/dev/null)
            file_size=$((file_size / 1024 / 1024))
            if [ "$file_size" != "$swap_size" ]; then
                swapoff "$SWAP_FILE" 2>/dev/null || true
                rm -f "$SWAP_FILE" 2>/dev/null
            fi
        fi
        set_value true /sys/kernel/mm/swap/vma_ra_enabled 2>/dev/null
        if [ ! -f "$SWAP_FILE" ]; then
            if [ "$KERNEL_VERSION_1" -ge 5 ]; then
                fallocate -l "${swap_size}M" "$SWAP_FILE" 2>/dev/null || dd if=/dev/zero of="$SWAP_FILE" bs=1m count="$swap_size" 2>/dev/null
            else
                dd if=/dev/zero of="$SWAP_FILE" bs=1m count="$swap_size" 2>/dev/null
            fi
            chmod 600 "$SWAP_FILE" 2>/dev/null
            chown root:root "$SWAP_FILE" 2>/dev/null
        fi
        if ! mkswap "$SWAP_FILE" >/dev/null 2>&1; then
            log_error "  mkswap 失败"
        fi
        if [ -n "$swap_priority" ] && [ "$swap_priority" -gt -1 ]; then
            swapon "$SWAP_FILE" -p "$swap_priority" >/dev/null 2>&1
        else
            swapon "$SWAP_FILE" >/dev/null 2>&1
        fi
        if cat /proc/swaps 2>/dev/null | grep -q "$SWAP_FILE"; then
            log_info "  Swapfile 已激活"
        else
            log_warn "  Swapfile 未能激活，尝试重新格式化"
            swapoff "$SWAP_FILE" 2>/dev/null || true
            mkswap "$SWAP_FILE" >/dev/null 2>&1
            swapon "$SWAP_FILE" >/dev/null 2>&1
            if cat /proc/swaps 2>/dev/null | grep -q "$SWAP_FILE"; then
                log_info "  Swapfile 重试激活成功"
            else
                log_error "  Swapfile 激活失败"
            fi
        fi
    else
        log_info "未启用 Swapfile"
        if [ -f "$SWAP_FILE" ]; then
            swapoff "$SWAP_FILE" 2>/dev/null || true
        fi
        rm -f "$SWAP_FILE" 2>/dev/null
    fi
}

set_swap_ext() {
    if [ -e "$BLK_OPLUS_CRYPTO" ]; then
        blk_val=$(cat /sys/block/zram0/hybridswap_loop_device 2>/dev/null)
        if [ -z "$blk_val" ] || [ "$blk_val" = "none" ]; then
            mkswap "$BLK_OPLUS_CRYPTO" >/dev/null 2>&1
            swapon "$BLK_OPLUS_CRYPTO" >/dev/null 2>&1
        fi
    fi
}

set_zram() {
    if [ ! -e /dev/block/zram0 ]; then
        if [ -e /sys/class/zram-control ]; then
            cat /sys/class/zram-control/hot_add >/dev/null 2>&1
        else
            log_error "  内核不支持 ZRAM"
            return
        fi
    fi
    if [ "$zram" = "true" ] && [ -n "$zram_size" ] && [ "$zram_size" != "0" ]; then
        swapoff /dev/block/zram0 2>/dev/null
        zram_increase=0
        if nandswap_supported && [ "$zram_writeback" = "true" ]; then
            zram_increase=4096
        elif smartswap_supported && [ "$zram_writeback" = "true" ]; then
            zram_increase=4096
        fi
        set_value 1 /sys/block/zram0/reset
        set_value 4 /sys/block/zram0/max_comp_streams
        log_info "  设置 ZRAM 压缩方式 $comp_algorithm"
        for alg in $comp_algorithm zstd zstdn lz4k lz4 lzo-rle lzo; do
            echo "$alg" > /sys/block/zram0/comp_algorithm 2>/dev/null && break
        done
        disk_size=$zram_size
        if [ "$zram_increase" -gt 0 ]; then
            disk_size=$((zram_size + zram_increase))
        fi
        log_info "  设置 ZRAM 大小 $disk_size (+${zram_increase})"
        echo "${disk_size}m" > /sys/block/zram0/disksize
        mkswap /dev/block/zram0 >/dev/null 2>&1
        set_value 32768 /dev/memcg/memory.zram_used_limit_mb 2>/dev/null
        set_value 32768 /dev/memcg/memory.zram_critical_threshold 2>/dev/null
        log_info "  启动 ZRAM $(cat /sys/block/zram0/disksize) $(cat /sys/block/zram0/comp_algorithm)"
        swapon /dev/block/zram0 -p 0 >/dev/null 2>&1
        if cat /proc/swaps 2>/dev/null | grep -q '/dev/block/zram0'; then
            log_info "  ZRAM 已激活"
        else
            log_warn "  ZRAM 未能激活，重试..."
            sleep 1
            swapon /dev/block/zram0 -p 0 >/dev/null 2>&1
            if cat /proc/swaps 2>/dev/null | grep -q '/dev/block/zram0'; then
                log_info "  ZRAM 重试激活成功"
            else
                log_error "  ZRAM 激活失败"
            fi
        fi
        if nandswap_supported && [ "$zram_writeback" = "true" ]; then
            set_nandswap "$zram_increase"
        elif smartswap_supported && [ "$zram_writeback" = "true" ]; then
            set_smartswap "$zram_increase"
        else
            release_nandswap
            release_smartswap
        fi
    else
        log_info "未配置 ZRAM (zram=$zram, zram_size=$zram_size)"
    fi
}

set_vm_params() {
    if [ -n "$watermark_scale_factor" ]; then
        set_value "$watermark_scale_factor" /proc/sys/vm/watermark_scale_factor
    fi
    lock_value 0 /proc/sys/vm/watermark_boost_factor
    if [ -f /proc/sys/vm/extra_free_kbytes ] && [ -n "$extra_free_kbytes" ]; then
        set_value "$extra_free_kbytes" /proc/sys/vm/extra_free_kbytes
        resetprop sys.sysctl.extra_free_kbytes "$extra_free_kbytes" 2>/dev/null || true
    fi
    if [ -z "$swappiness" ] || [ "$swappiness" = "auto" ]; then
        swappiness_max=$(get_swappiness_max)
        if [ "$swappiness_max" -gt 100 ]; then
            swappiness=125
        else
            swappiness=100
        fi
        log_info "  swappiness: ${swappiness} (自动)"
    fi
    if [ -n "$swappiness" ]; then
        lock_value "$swappiness" /proc/sys/vm/swappiness
        lock_value "$swappiness" /dev/memcg/memory.swappiness 2>/dev/null
        lock_value "$swappiness" /dev/memcg/apps/memory.swappiness 2>/dev/null
        lock_value "$swappiness" /sys/fs/cgroup/memory/apps/memory.swappiness 2>/dev/null
        lock_value "$swappiness" /sys/fs/cgroup/memory/memory.swappiness 2>/dev/null
    fi
    set_value 2 /proc/sys/vm/dirty_background_ratio
    set_value 5 /proc/sys/vm/dirty_ratio
    set_value 3000 /proc/sys/vm/dirty_expire_centisecs
    set_value 5000 /proc/sys/vm/dirty_writeback_centisecs
    set_value 150 /proc/sys/vm/vfs_cache_pressure
    set_value 0 /proc/sys/vm/swap_ratio_enable
    lock_value 1 /proc/sys/vm/overcommit_memory
    set_value 0 /proc/sys/vm/panic_on_oom
    case "$comp_algorithm" in
        zstd*) set_value 0 /proc/sys/vm/page-cluster ;;
        *) set_value 1 /proc/sys/vm/page-cluster ;;
    esac
}

set_lmk_params() {
    resetprop persist.sys.minfree_6g "16384,20480,32768,131072,262144,384000" 2>/dev/null || true
    resetprop persist.sys.minfree_8g "16384,20480,32768,131072,384000,524288" 2>/dev/null || true
    resetprop persist.sys.minfree_12g "16384,20480,131072,384000,524288,819200" 2>/dev/null || true
}

dis_reclaim() {
    ppr=/sys/module/process_reclaim/parameters
    if [ -d "$ppr" ]; then
        set_value 0 "$ppr/enable_process_reclaim"
    fi
    set_value 0 /sys/kernel/mi_reclaim/enable 2>/dev/null || true
    set_value 0 /sys/kernel/low_free/low_free_enable 2>/dev/null || true
    set_value 0 /sys/kernel/mi_reclaim/greclaim_enable 2>/dev/null || true
}

device_configs() {
    if command -v device_config >/dev/null 2>&1; then
        device_config put activity_manager max_cached_processes 32768 2>/dev/null || true
        device_config put activity_manager max_phantom_processes 32768 2>/dev/null || true
    fi
}

if [ "$zram" = "true" ]; then
    swapoff /dev/block/zram0 2>/dev/null
fi

set_value off /sys/kernel/mm/damon/admin/kdamonds/0/state 2>/dev/null || true
set_value off /sys/kernel/mm/damon/admin/kdamonds/1/state 2>/dev/null || true
lock_value 0 /sys/kernel/mm/damon/admin/kdamonds/nr_kdamonds 2>/dev/null || true
dis_reclaim

set_zram
set_swap_ext
set_swap
set_lmk_params
set_vm_params
device_configs
