#!/system/bin/sh

SCENE_MEMCG=""
if [ -f /sys/fs/cgroup/memory/memory.swappiness ]; then
    SCENE_MEMCG="/sys/fs/cgroup/memory"
elif [ -f /dev/memcg/memory.swappiness ]; then
    SCENE_MEMCG="/dev/memcg"
fi

check_daemon_supported() {
    top_app="/dev/cpuset/top-app/cgroup.procs"
    bg_app="/dev/cpuset/background/cgroup.procs"
    fg_app="/dev/cpuset/foreground/cgroup.procs"
    if [ ! -f "$MODDIR/scripts/service.dex" ]; then
        echo "NotSupported"
    elif [ ! -f "$top_app" ] || [ ! -f "$bg_app" ]; then
        echo "NotSupported"
    elif [ -f /dev/memcg/memory.force_swapout ] || [ -f /dev/memcg/memory.force_reclaim_zram ]; then
        echo "Level3"
    elif [ -f "$fg_app" ] && [ "$SDK_VERSION" -gt 27 ] && [ "$SDK_VERSION" -lt 34 ]; then
        if [ -n "$SCENE_MEMCG" ]; then
            if [ -e /proc/1/reclaim ] && [ "$MEM_TOTAL_GB" -gt 4 ]; then
                echo "Level0"
            else
                echo "Level1"
            fi
        else
            echo "Level2"
        fi
    else
        echo "Level3"
    fi
}

get_daemon_config() {
    policy=$1
    supported=$(check_daemon_supported)
    if [ "$supported" = "Level3" ]; then
        if [ "$policy" != "kill" ] && [ "$policy" != "off" ]; then
            policy="kill"
        fi
    fi
    echo "daemon_service=$policy"
    echo "daemon_used_limit=175%"
}
