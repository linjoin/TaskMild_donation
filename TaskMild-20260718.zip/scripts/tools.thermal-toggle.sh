#!/system/bin/sh

set +e

MODDIR="/data/adb/modules/taskmild"
STAGING="$MODDIR/thermal_override"
CONF="/data/adb/taskmild/config/taskmild.conf"
WORKDIR="/data/adb/taskmild"
DATA_DIR="$WORKDIR/data"
LOGS_DIR="$WORKDIR/logs"
MOUNT_PARTS="system product system_ext"
BIND_STATE_FILE="$DATA_DIR/thermal_mounts.list"
BIND_LOG_FILE="$LOGS_DIR/thermal_bind.log"

mkdir -p "$DATA_DIR" "$LOGS_DIR" 2>/dev/null || true

MODE="default"
[ "$1" = "--apply" ] && MODE="apply"
[ "$1" = "--json" ] && MODE="json"
[ "$1" = "--status" ] && MODE="status"
[ "$1" = "--bindinfo" ] && MODE="bindinfo"

bind_log() {
    printf '[%s] %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$1" >> "$BIND_LOG_FILE" 2>/dev/null || true
}

ensure_init_mount_ns() {
    _self_ns=$(readlink /proc/self/ns/mnt 2>/dev/null || echo "")
    _init_ns=$(readlink /proc/1/ns/mnt 2>/dev/null || echo "")
    [ -n "$_self_ns" ] && [ -n "$_init_ns" ] && [ "$_self_ns" = "$_init_ns" ] && return 0
    if command -v nsenter >/dev/null 2>&1 && [ -d /proc/1/ns/mnt ]; then
        exec nsenter -t 1 -m "$0" "$@"
    fi
    bind_log "警告: nsenter 不可用, 在当前命名空间执行 bind-mount (可能不传播)"
    return 0
}

if [ "$(id -u 2>/dev/null || echo 1)" -ne 0 ]; then
    if [ "$MODE" = "json" ]; then
        echo '{"ok":false,"error":"需要 root 权限","code":2}'
    else
        echo "! 需要 root 权限执行"
    fi
    exit 2
fi

ensure_init_mount_ns "$@"

read_thermal_enable() {
    if [ -f "$CONF" ]; then
        _val=$(sed -n 's|^thermal_enable=||p' "$CONF" 2>/dev/null | head -n1 | tr -d '[:space:]')
        case "$_val" in
            on|off) printf '%s' "$_val" ;;
            *) printf 'off' ;;
        esac
    else
        printf 'off'
    fi
}

count_staged() {
    if [ -d "$STAGING" ]; then
        find "$STAGING" -type f 2>/dev/null | wc -l
    else
        echo 0
    fi
}

count_mounted() {
    _cnt=0
    for _part in $MOUNT_PARTS; do
        _staged_part="$STAGING/$_part"
        [ -d "$_staged_part" ] || continue
        ( cd "$_staged_part" 2>/dev/null && find . -type f 2>/dev/null ) | while IFS= read -r _f; do
            _f="${_f#./}"
            _target="$MODDIR/$_part/$_f"
            if [ -f "$_target" ]; then
                echo 1
            fi
        done
    done | wc -l
}

check_live_active() {

    for _p in \
        /vendor/etc/thermal/thermal.conf \
        /system/vendor/etc/thermal/thermal.conf \
        /vendor/etc/thermal-engine.conf \
        /system/vendor/etc/thermal-engine.conf \
        /system/etc/thermal-engine.conf \
        /system_ext/bin/thermald \
        /system/system_ext/bin/thermald \
        /vendor/etc/thermald-devices.conf
    do
        if [ -f "$_p" ]; then
            _sz=$(stat -c %s "$_p" 2>/dev/null || echo 1)
            [ "$_sz" = "0" ] && return 0
        fi
    done

    _check_script="$MODDIR/scripts/tools.thermal-check.sh"
    if [ -f "$_check_script" ]; then
        _json=$(sh "$_check_script" --json 2>/dev/null)
        if [ -n "$_json" ]; then
            _blocked=$(echo "$_json" | sed -n 's/.*"blocked":\([0-9]*\).*/\1/p' 2>/dev/null)
            [ -n "$_blocked" ] && [ "$_blocked" -gt 0 ] 2>/dev/null && return 0
            return 1
        fi
    fi

    _found_active=0
    find /system /vendor /product /system_ext -type f -iname "*thermal*" 2>/dev/null \
        | grep -v '/hardware/' | grep -v '\.so$' \
        | while IFS= read -r _f; do
            _sz=$(stat -c %s "$_f" 2>/dev/null || echo 1)
            [ "$_sz" = "0" ] && exit 0
        done
    [ $? -eq 0 ]
}

do_enable() {
    _added=0
    _skipped=0
    for _part in $MOUNT_PARTS; do
        _staged_part="$STAGING/$_part"
        [ -d "$_staged_part" ] || continue
        while IFS= read -r _f; do
            [ -z "$_f" ] && continue
            _f="${_f#./}"
            _target_dir="$MODDIR/$_part/$(dirname "$_f")"
            _target="$MODDIR/$_part/$_f"
            mkdir -p "$_target_dir" 2>/dev/null
            if [ ! -f "$_target" ]; then
                cp -a "$_staged_part/$_f" "$_target" 2>/dev/null && _added=$((_added + 1))
            else
                _skipped=$((_skipped + 1))
            fi
        done <<EOF
$(cd "$_staged_part" 2>/dev/null && find . -type f 2>/dev/null)
EOF
    done
    printf '%s %s' "$_added" "$_skipped"
}

do_disable() {
    _removed=0
    _skipped=0
    for _part in $MOUNT_PARTS; do
        _staged_part="$STAGING/$_part"
        [ -d "$_staged_part" ] || continue
        while IFS= read -r _f; do
            _f="${_f#./}"
            _target="$MODDIR/$_part/$_f"
            if [ -f "$_target" ]; then
                rm -f "$_target" 2>/dev/null && _removed=$((_removed + 1))
                _d="$(dirname "$_target")"
                while [ "$_d" != "$MODDIR/$_part" ] && [ -d "$_d" ]; do
                    rmdir "$_d" 2>/dev/null || break
                    _d="$(dirname "$_d")"
                done
            else
                _skipped=$((_skipped + 1))
            fi
        done <<EOF
$(cd "$_staged_part" 2>/dev/null && find . -type f 2>/dev/null)
EOF
    done
    printf '%s %s' "$_removed" "$_skipped"
}

do_enable_bindmount() {
    _bound=0
    _bskip=0
    _bfail=0
    : > "$BIND_STATE_FILE" 2>/dev/null || true
    bind_log "=== do_enable_bindmount 开始 ==="
    for _part in $MOUNT_PARTS; do
        _staged_part="$STAGING/$_part"
        [ -d "$_staged_part" ] || continue
        while IFS= read -r _f; do
            [ -z "$_f" ] && continue
            _f="${_f#./}"
            _staged="$STAGING/$_part/$_f"
            [ -f "$_staged" ] || continue
            _raw_target="/$_part/$_f"
            _tdir=$(dirname "$_raw_target")
            _rdir=$(readlink -f "$_tdir" 2>/dev/null || echo "$_tdir")
            _rtarget="$_rdir/$(basename "$_f")"
            if [ ! -e "$_rtarget" ] && [ ! -L "$_rtarget" ]; then
                _bskip=$((_bskip + 1))
                continue
            fi
            _sz=$(stat -c %s "$_rtarget" 2>/dev/null || echo 1)
            if [ "$_sz" = "0" ]; then
                _bskip=$((_bskip + 1))
                echo "$_rtarget" >> "$BIND_STATE_FILE"
                continue
            fi
            if mount --bind "$_staged" "$_rtarget" 2>/dev/null; then
                _bound=$((_bound + 1))
                echo "$_rtarget" >> "$BIND_STATE_FILE"
                bind_log "bind OK: $_staged -> $_rtarget"
            else
                _bfail=$((_bfail + 1))
                bind_log "bind 失败: $_staged -> $_rtarget"
            fi
        done <<EOF
$(cd "$_staged_part" 2>/dev/null && find . -type f 2>/dev/null)
EOF
    done
    bind_log "=== do_enable_bindmount 完成: bind=$_bound skip=$_bskip fail=$_bfail ==="
    printf '%s %s %s' "$_bound" "$_bskip" "$_bfail"
}

do_disable_bindmount() {
    _unmounted=0
    _uskip=0
    _ufail=0
    [ -f "$BIND_STATE_FILE" ] || {
        bind_log "do_disable_bindmount: 状态文件不存在, 无需卸载"
        printf '0 0 0'
        return 0
    }
    bind_log "=== do_disable_bindmount 开始 ==="
    _lines=$(tac "$BIND_STATE_FILE" 2>/dev/null || cat "$BIND_STATE_FILE")
    printf '%s\n' "$_lines" | while IFS= read -r _p; do
        [ -z "$_p" ] && continue
        _is_mounted=0
        if command -v findmnt >/dev/null 2>&1; then
            findmnt --target "$_p" >/dev/null 2>&1 && _is_mounted=1
        else
            mount 2>/dev/null | grep -q " on $_p " && _is_mounted=1
        fi
        if [ "$_is_mounted" = "1" ]; then
            if umount "$_p" 2>/dev/null; then
                bind_log "umount OK: $_p"
            else
                bind_log "umount 失败: $_p"
            fi
        fi
    done
    : > "$BIND_STATE_FILE" 2>/dev/null || true
    bind_log "=== do_disable_bindmount 完成 ==="
    printf '0 0 0'
}

STAGED_COUNT=$(count_staged)

if [ "$STAGED_COUNT" -eq 0 ]; then
    case "$MODE" in
        json)
            echo '{"ok":false,"enabled":false,"staged":0,"error":"thermal_override 暂存区不存在","code":1}'
            ;;
        apply) exit 1 ;;
        status)
            echo "温控屏蔽: 未内置 (暂存区不存在)"
            exit 1
            ;;
        *)
            echo "! 温控屏蔽暂存区不存在 (模块未内置温控屏蔽功能)"
            exit 1
            ;;
    esac
    exit 1
fi

ENABLED=$(read_thermal_enable)

if [ "$MODE" = "status" ]; then
    MOUNTED=$(count_mounted)
    BIND_ACTIVE=0
    if [ -f "$BIND_STATE_FILE" ]; then
        BIND_ACTIVE=$(wc -l < "$BIND_STATE_FILE" 2>/dev/null | tr -d '[:space:]')
        [ -z "$BIND_ACTIVE" ] && BIND_ACTIVE=0
    fi
    if [ "$ENABLED" = "on" ]; then
        echo "温控屏蔽配置: 已启用 (thermal_enable=on)"
    else
        echo "温控屏蔽配置: 已禁用 (thermal_enable=off)"
    fi
    echo "暂存区文件数: $STAGED_COUNT"
    echo "已挂载文件数: $MOUNTED"
    echo "bind-mount 活跃: $BIND_ACTIVE 个路径"
    if check_live_active; then
        LIVE_ACTIVE=1
        echo "实时挂载: 已生效"
    else
        LIVE_ACTIVE=0
        echo "实时挂载: 未生效"
    fi
    if [ "$ENABLED" = "on" ] && [ "$LIVE_ACTIVE" = "0" ]; then
        if [ "$BIND_ACTIVE" -gt 0 ]; then
            echo "状态: bind-mount 已生效但检测未通过 (可能命名空间隔离)"
        else
            echo "状态: 配置已启用但实时挂载未生效 (需重启或执行 --apply)"
        fi
    elif [ "$ENABLED" = "on" ] && [ "$LIVE_ACTIVE" = "1" ]; then
        echo "状态: 配置已启用且实时生效"
    elif [ "$ENABLED" = "off" ] && [ "$LIVE_ACTIVE" = "1" ]; then
        echo "状态: 配置已禁用但实时仍有屏蔽 (需重启设备恢复)"
    elif [ "$ENABLED" = "off" ] && [ "$MOUNTED" -gt 0 ]; then
        echo "状态: 配置已禁用但仍有文件挂载 (重启或执行 --apply 同步)"
    else
        echo "状态: 配置与挂载一致"
    fi
    exit 0
fi

CHANGED=0
RESULT_ADD=0
RESULT_SKIP=0
RESULT_BIND=0
RESULT_BINDSKIP=0
RESULT_BINDFAIL=0
if [ "$ENABLED" = "on" ]; then
    _out=$(do_enable)
    RESULT_ADD=$(echo "$_out" | awk '{print $1}')
    RESULT_SKIP=$(echo "$_out" | awk '{print $2}')
    _bout=$(do_enable_bindmount)
    RESULT_BIND=$(echo "$_bout" | awk '{print $1}')
    RESULT_BINDSKIP=$(echo "$_bout" | awk '{print $2}')
    RESULT_BINDFAIL=$(echo "$_bout" | awk '{print $3}')
    ACTION="enable"
else
    _bout=$(do_disable_bindmount)
    RESULT_BIND=$(echo "$_bout" | awk '{print $1}')
    RESULT_BINDSKIP=$(echo "$_bout" | awk '{print $2}')
    RESULT_BINDFAIL=$(echo "$_bout" | awk '{print $3}')
    _out=$(do_disable)
    RESULT_ADD=$(echo "$_out" | awk '{print $1}')
    RESULT_SKIP=$(echo "$_out" | awk '{print $2}')
    ACTION="disable"
fi

if [ "$MODE" = "apply" ]; then
    bind_log "apply 模式: $ACTION 完成, 跳过状态报告计算 (快速退出)"
    exit 0
fi

MOUNTED=$(count_mounted)

if check_live_active; then
    LIVE_ACTIVE=true
else
    LIVE_ACTIVE=false
fi

if [ "$ENABLED" = "on" ] && [ "$LIVE_ACTIVE" = "false" ]; then
    REBOOT_NEEDED=true
elif [ "$ENABLED" = "off" ] && [ "$LIVE_ACTIVE" = "true" ]; then
    REBOOT_NEEDED=true
else
    REBOOT_NEEDED=false
fi

LIVE_BLOCKED=-1
LIVE_LEAKED=-1
_check_script="$MODDIR/scripts/tools.thermal-check.sh"
if [ -f "$_check_script" ]; then
    _cjson=$(sh "$_check_script" --json 2>/dev/null)
    if [ -n "$_cjson" ]; then
        LIVE_BLOCKED=$(echo "$_cjson" | sed -n 's/.*"blocked":\([0-9]*\).*/\1/p' 2>/dev/null)
        LIVE_LEAKED=$(echo "$_cjson" | sed -n 's/.*"leaked":\([0-9]*\).*/\1/p' 2>/dev/null)
        [ -z "$LIVE_BLOCKED" ] && LIVE_BLOCKED=-1
        [ -z "$LIVE_LEAKED" ] && LIVE_LEAKED=-1
    fi
fi

case "$MODE" in
    json)
        printf '{"ok":true,"enabled":%s,"action":"%s","staged":%d,"mounted":%d,"changed":%d,"skipped":%d,"bind_mounted":%d,"bind_skipped":%d,"bind_failed":%d,"live_active":%s,"reboot_needed":%s,"live_blocked":%d,"live_leaked":%d}\n' \
            "$( [ "$ENABLED" = "on" ] && echo true || echo false )" \
            "$ACTION" "$STAGED_COUNT" "$MOUNTED" "$RESULT_ADD" "$RESULT_SKIP" \
            "$RESULT_BIND" "$RESULT_BINDSKIP" "$RESULT_BINDFAIL" \
            "$LIVE_ACTIVE" "$REBOOT_NEEDED" "$LIVE_BLOCKED" "$LIVE_LEAKED"
        ;;
    apply)
        exit 0
        ;;
    bindinfo)
        if [ -f "$BIND_STATE_FILE" ]; then
            _bc=$(wc -l < "$BIND_STATE_FILE" 2>/dev/null || echo 0)
            echo "bind-mount 状态文件: $BIND_STATE_FILE"
            echo "已记录 bind 路径数: $_bc"
            if [ "$_bc" -gt 0 ] && [ "$_bc" -le 20 ]; then
                echo "--- 已 bind 路径 ---"
                cat "$BIND_STATE_FILE"
            elif [ "$_bc" -gt 20 ]; then
                echo "--- 前 20 条 ---"
                head -20 "$BIND_STATE_FILE"
                echo "... (共 $_bc 条)"
            fi
        else
            echo "bind-mount 状态文件不存在 (未执行过 enable)"
        fi
        echo "bind-mount 日志: $BIND_LOG_FILE"
        if [ -f "$BIND_LOG_FILE" ]; then
            echo "--- 最近 10 条日志 ---"
            tail -10 "$BIND_LOG_FILE"
        fi
        exit 0
        ;;
    *)
        if [ "$ENABLED" = "on" ]; then
            echo "温控屏蔽: 已启用 (thermal_enable=on)"
            echo "  overlay 拷贝: 新增 $RESULT_ADD, 跳过 $RESULT_SKIP"
            echo "  bind-mount:  成功 $RESULT_BIND, 跳过 $RESULT_BINDSKIP, 失败 $RESULT_BINDFAIL"
            echo "  暂存区总数:  $STAGED_COUNT 个文件"
            echo "  当前已挂载:  $MOUNTED 个文件 (overlay 路径)"
        else
            echo "温控屏蔽: 已禁用 (thermal_enable=off)"
            echo "  bind-mount 卸载: 成功 $RESULT_BIND, 跳过 $RESULT_BINDSKIP, 失败 $RESULT_BINDFAIL"
            echo "  overlay 移除:   $RESULT_ADD 个文件"
            echo "  暂存区保留:    $STAGED_COUNT 个文件 (未删除)"
        fi
        if [ "$LIVE_ACTIVE" = "true" ]; then
            echo "  实时挂载: 已生效 ✓"
        else
            echo "  实时挂载: 未生效 (overlay + bind 均未覆盖)"
        fi
        if [ "$LIVE_BLOCKED" -ge 0 ] 2>/dev/null; then
            echo "  实时屏蔽: $LIVE_BLOCKED 个 (0字节)"
            echo "  实时漏网: $LIVE_LEAKED 个 (非零)"
            if [ "$LIVE_BLOCKED" -eq 0 ] && [ "$LIVE_LEAKED" -gt 0 ] && [ "$ENABLED" = "on" ]; then
                echo "  诊断: 0 个温控文件被屏蔽, 可能原因:"
                echo "    1. KernelSU/Magisk 模块未启用 (检查管理器中模块开关)"
                echo "    2. KSU 元模块剥离了挂载权限 (已用 bind-mount 绕过, 检查 bind 失败数)"
                echo "    3. service.sh 未在 init 命名空间执行 (查看 $BIND_LOG_FILE)"
                echo "    4. 提示: 运行 tools.thermal-toggle.sh --bindinfo 查看 bind-mount 详情"
            fi
        fi
        ;;
esac
exit 0
