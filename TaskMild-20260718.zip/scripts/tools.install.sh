#!/system/bin/sh

MODDIR=${0%/*}
MODDIR=$(readlink -f "$MODDIR" 2>/dev/null || echo "$MODDIR")

. "$MODDIR/tools.sh"

ufs_health_ok() {
    bDeviceLifeTimeEstA=$(cat /sys/devices/platform/soc/*ufshc*/health_descriptor/life_time_estimation_a 2>/dev/null)
    if [ -z "$bDeviceLifeTimeEstA" ]; then
        bDeviceLifeTimeEstA=$(grep bDeviceLifeTimeEstA /sys/kernel/debug/*.ufshc/dump_health_desc 2>/dev/null | cut -f2 -d '=' | cut -f2 -d ' ')
    fi
    case "$bDeviceLifeTimeEstA" in
        "0x01"|"0x1"|"0x02"|"0x2") return_true; return ;;
    esac
    return_false
}

hp_soc() {
    max_freq=0
    for c in /sys/devices/system/cpu/cpufreq/policy*; do
        freq=$(cat "$c/cpuinfo_max_freq" 2>/dev/null)
        if [ -n "$freq" ] && [ "$freq" -gt "$max_freq" ]; then
            max_freq=$freq
        fi
    done
    if [ "$max_freq" -gt 3000000 ]; then
        return_true
        return
    fi
    return_false
}
