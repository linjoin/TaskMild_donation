#!/system/bin/sh

MODDIR=${0%/*}
MODDIR=$(readlink -f "$MODDIR" 2>/dev/null || echo "$MODDIR")

. "$MODDIR/tools.sh"
. "$MODDIR/tools.startup.sh"
. "$MODDIR/tools.nandswap.sh"

import_config

if [ -z "$daemon_service" ] || [ "$daemon_service" = "off" ]; then
    exit 0
fi

if [ -z "$daemon_used_limit" ]; then
    daemon_used_limit='175%'
fi

LOG_FILE='/data/adb/taskmild/run.log'

log_info() {
    printf '[%s] [信息] %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$1" >> "$LOG_FILE" 2>/dev/null || true
}

log_warn() {
    printf '[%s] [警告] %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$1" >> "$LOG_FILE" 2>/dev/null || true
}

log_error() {
    printf '[%s] [错误] %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$1" >> "$LOG_FILE" 2>/dev/null || true
}

SCENE_MEMCG=""
if [ -f /sys/fs/cgroup/memory/memory.swappiness ]; then
    SCENE_MEMCG="/sys/fs/cgroup/memory"
elif [ -f /dev/memcg/memory.swappiness ]; then
    SCENE_MEMCG="/dev/memcg"
fi

if [ -n "$SCENE_MEMCG" ]; then
    nom_swappiness=$(cat /proc/sys/vm/swappiness)
    sys_swappiness=60
    active_swappiness=60
    idle_swappiness=$(get_swappiness_max)
    if [ "$KERNEL_VERSION_1" -ge 5 ]; then
        active_swappiness=125
    fi
    sys_swappiness=$(min_val "$sys_swappiness" "$nom_swappiness")
    active_swappiness=$(min_val "$active_swappiness" "$nom_swappiness")

    _cleanup_i=0
    while [ "$_cleanup_i" -lt 5 ]; do
        find "$SCENE_MEMCG" -name '*procs' -exec dirname {} \; 2>/dev/null | while read -r dir; do
            rmdir "$dir" 2>/dev/null || true
        done
        _cleanup_i=$((_cleanup_i + 1))
    done
    init_group apps "$nom_swappiness"
    init_group system "$sys_swappiness"
    init_group scene_active "$active_swappiness"
    init_group scene_idle "$idle_swappiness"

    find "$SCENE_MEMCG" -name memory.move_charge_at_immigrate 2>/dev/null | while read -r row; do
        echo 1 > "$row" 2>/dev/null || true
    done

    if [ "$daemon_service" = "lazy" ]; then
        limit=$((MEM_TOTAL_KB/1024/4))
        limit=$(min_val "$limit" 1024)
        echo "${limit}M" > "$SCENE_MEMCG/scene_idle/memory.soft_limit_in_bytes" 2>/dev/null || true
    fi
else
    if [ "$daemon_service" != "basic" ]; then
        daemon_service="basic"
    fi
fi

if [ -f "$MODDIR/scripts/service.dex" ]; then
    log_info "启动 CGroup 守护服务 (daemon_service=$daemon_service, limit=$daemon_used_limit)"
    nohup dalvikvm -cp "$MODDIR/scripts/service.dex" Main "$daemon_service" "$daemon_used_limit" >> "$LOG_FILE" 2>&1 &
fi
