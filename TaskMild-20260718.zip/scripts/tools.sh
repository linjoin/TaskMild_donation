#!/system/bin/sh

set -u

MODDIR=${0%/*}
MODDIR=$(readlink -f "$MODDIR" 2>/dev/null || echo "$MODDIR")

export MODDIR

export SDK_VERSION
export KERNEL_VERSION
export KERNEL_VERSION_1
export PLATFORM
export SOC
export MEM_TOTAL_KB
export MEM_TOTAL_GB
SDK_VERSION=$(getprop ro.build.version.sdk)
KERNEL_VERSION=$(uname -r | cut -d'-' -f1)
KERNEL_VERSION_1=$(echo "$KERNEL_VERSION" | cut -d'.' -f1)
PLATFORM=$(getprop ro.board.platform)
SOC=$(getprop ro.soc.model | tr '[:lower:]' '[:upper:]')

MEM_TOTAL_STR=$(grep MemTotal /proc/meminfo)
MEM_TOTAL_KB=$(echo "$MEM_TOTAL_STR" | awk '{print $2}')
MEM_TOTAL_GB=$(((MEM_TOTAL_KB / 1024 + 2047) / 2048 * 2))

alias return_false="return 99"
alias return_true="return 0"

min_val() {
    if [ "$1" -lt "$2" ]; then echo "$1"; else echo "$2"; fi
}

max_val() {
    if [ "$1" -gt "$2" ]; then echo "$1"; else echo "$2"; fi
}

compare_versions() {
    if [ "$1" = "$2" ]; then
        echo 0
        return
    fi
    awk -v a="$1" -v b="$2" 'BEGIN {
        split(a, va, "."); split(b, vb, ".");
        for (i = 1; i <= 3; i++) {
            if (va[i] == "") va[i] = 0;
            if (vb[i] == "") vb[i] = 0;
            if (va[i]+0 > vb[i]+0) { print 1; exit; }
            if (va[i]+0 < vb[i]+0) { print -1; exit; }
        }
        print 0;
    }'
}

kernel_compare() {
    compare_versions "$1" "$KERNEL_VERSION"
}

wait_until_login() {
    _wait_count=0
    while [ "$(getprop sys.boot_completed)" != "1" ]; do
        sleep 1
        _wait_count=$((_wait_count + 1))
        [ "$_wait_count" -gt 120 ] && return 1
    done
    _wait_count=0
    until [ -d "/data/data/android" ]; do
        sleep 1
        _wait_count=$((_wait_count + 1))
        [ "$_wait_count" -gt 120 ] && return 1
    done
    return 0
}

set_value() {
    if [ -f "$2" ]; then
        chmod 644 "$2" 2>/dev/null
        echo "$1" > "$2" 2>/dev/null || true
    fi
}

lock_value() {
    if [ -f "$2" ]; then
        chmod 644 "$2" 2>/dev/null
        echo "$1" > "$2" 2>/dev/null || true
        chown root:root "$2" 2>/dev/null
        chmod 444 "$2" 2>/dev/null
    fi
}

update_prop() {
    prop="$1"
    value="$2"
    sed -i "s/^$prop=.*/$prop=$value/" "${MODPATH:-}/system.prop" 2>/dev/null || true
}

get_swappiness_max() {
    current=$(cat /proc/sys/vm/swappiness)
    echo 100 > /proc/sys/vm/swappiness
    echo 150 > /proc/sys/vm/swappiness 2>/dev/null
    echo 200 > /proc/sys/vm/swappiness 2>/dev/null
    max_val=$(cat /proc/sys/vm/swappiness)
    echo "$current" > /proc/sys/vm/swappiness
    echo "$max_val"
}

read_config_value() {
    conf="/data/adb/taskmild/taskmild.conf"
    if [ -f "$conf" ]; then
        sed -n "s/^$1=//p" "$conf" 2>/dev/null | head -n 1
    fi
}
