#!/system/bin/sh

set -u

readonly WORKDIR="/data/adb/taskmild"
readonly MODDIR="/data/adb/modules/taskmild"
readonly CONFIG_DIR="$WORKDIR/config"
readonly LOCK_DIR="$WORKDIR/lock"
readonly LOGS_DIR="$WORKDIR/logs"
readonly DATA_DIR="$WORKDIR/data"
readonly DIAG_DIR="$WORKDIR/diag"
readonly LOG_FILE="$LOGS_DIR/run.log"
readonly CONF_FILE="$CONFIG_DIR/taskmild.conf"
readonly BIN_DIR="$WORKDIR/bin"
readonly TS=$(date '+%Y%m%d_%H%M%S')
readonly STAGE="$DIAG_DIR/.stage_$$_$TS"
readonly OUT_FILE="$DIAG_DIR/diag_$TS.tar.gz"
readonly MAX_ARCHIVES=5
readonly DMESG_TAIL=200
readonly TOP_N=30

find_busybox() {
    for cand in \
        /data/adb/ksu/bin/busybox \
        /data/adb/ap/bin/busybox \
        /data/adb/magisk/busybox \
        /system/bin/busybox \
        /system/xbin/busybox
    do
        if [ -x "$cand" ] && "$cand" true >/dev/null 2>&1; then
            echo "$cand"
            return 0
        fi
    done
    return 1
}

BB=$(find_busybox 2>/dev/null || echo "")
has_bb() { [ -n "$BB" ] && "$BB" "$1" >/dev/null 2>&1; }

tar_cmd() {
    if [ -n "$BB" ] && "$BB" tar --version >/dev/null 2>&1; then
        "$BB" tar "$@"
    else
        tar "$@"
    fi
}

ls_la_z() {
    if [ -n "$BB" ]; then
        "$BB" ls -la -Z "$@" 2>/dev/null || "$BB" ls -la "$@" 2>/dev/null
    else
        ls -la -Z "$@" 2>/dev/null || ls -la "$@" 2>/dev/null
    fi
}

section() { printf '\n========================================\n%s\n========================================\n' "$1"; }

write_file() {
    printf '%s\n' "$1" > "$2" 2>/dev/null || true
}

append_file() {
    printf '%s\n' "$1" >> "$2" 2>/dev/null || true
}

capture_to() {
    local dest=""
    local args=""
    while [ $# -gt 0 ]; do
        if [ "$1" = "--" ]; then
            dest="$2"
            break
        fi
        args="$args \"$1\""
        shift
    done
    [ -n "$dest" ] || return 1
    eval "$args" > "$dest" 2>&1 || true
}

cat_to() {
    if [ -r "$1" ]; then
        cat "$1" > "$2" 2>/dev/null || printf '无法读取 %s\n' "$1" > "$2"
    else
        printf '文件不存在或不可读: %s\n' "$1" > "$2"
    fi
}

check_pass() { printf '  [PASS] %s\n' "$1"; }
check_fail() { printf '  [FAIL] %s\n' "$1"; }

check_file_readable() {
    if [ -r "$1" ]; then check_pass "$2"; else check_fail "$2"; fi
}

check_file_writable() {
    if [ -w "$1" ] 2>/dev/null; then check_pass "$2"; else check_fail "$2"; fi
}

check_dir_writable() {
    if [ -d "$1" ] && [ -w "$1" ]; then check_pass "$2"; else check_fail "$2"; fi
}

check_command() {
    if command -v "$1" >/dev/null 2>&1; then check_pass "$2"; else check_fail "$2"; fi
}

check_executable() {
    if [ -x "$1" ]; then check_pass "$2"; else check_fail "$2"; fi
}

collect_error_context() {
    local dest="$STAGE/00_error_context.txt"
    local reason=""
    if [ -n "${1:-}" ] && [ -f "$1" ]; then
        reason=$(cat "$1" 2>/dev/null || echo "(reason 文件读取失败: $1)")
    elif [ -n "${1:-}" ] && case "$1" in /*) true;; *) false;; esac; then
        reason="(reason 文件不存在: $1)"
    else
        reason="${1:-手动触发}"
    fi

    {
        section "TaskMild 诊断错误上下文"
        printf '\n'
        printf 'timestamp      = %s\n' "$(date '+%Y-%m-%d %H:%M:%S')"
        printf 'timestamp_unix = %s\n' "$(date '+%s')"
        printf 'boot_id        = %s\n' "$(cat /proc/sys/kernel/random/boot_id 2>/dev/null | head -n1 | tr -d ' \n')"
        printf 'uptime_secs    = %s\n' "$(cut -d' ' -f1 /proc/uptime 2>/dev/null || echo '?')"
        printf 'pid            = %s\n' "$$"
        printf 'ppid           = %s\n' "$(cat /proc/self/stat 2>/dev/null | cut -d' ' -f4 || echo '?')"
        printf 'uid            = %s (%s)\n' "$(id -u 2>/dev/null || echo '?')" "$(id -un 2>/dev/null || echo '?')"
        printf '\n'
        printf -- '--- 触发原因 ---\n'
        printf '%s\n' "$reason"
    } > "$dest" 2>/dev/null || true
}

collect_precondition_checks() {
    local dest="$STAGE/01_precondition_checks.txt"
    {
        section "TaskMild 前提条件检查"

        printf '\n[验证流程前提条件]\n'
        check_file_readable /proc/bootconfig "/proc/bootconfig 可读"
        check_file_readable /proc/device-tree/firmware/android/serialno "device-tree serialno 可读"
        check_file_readable /proc/cmdline "/proc/cmdline 可读"
        check_command curl "curl 可用 (云端下载)"
        check_command wget "wget 可用 (备用下载)"
        [ -n "$BB" ] && check_pass "busybox 可用 ($BB)" || check_fail "busybox 不可用"

        printf '\n[守护进程前提条件]\n'
        check_dir_writable "$WORKDIR" "工作目录 $WORKDIR 可写"
        check_dir_writable "$BIN_DIR" "bin 目录 $BIN_DIR 可写"
        check_executable "$BIN_DIR/taskmild" "taskmild 二进制可执行"
        check_file_writable "$LOG_FILE" "日志文件 $LOG_FILE 可写"
        check_file_readable "$CONF_FILE" "配置文件 $CONF_FILE 可读"

        printf '\n[Swap/ZRAM 前提条件]\n'
        check_file_readable /proc/swaps "/proc/swaps 可读"
        [ -b /dev/block/zram0 ] && check_pass "/dev/block/zram0 存在" || check_fail "/dev/block/zram0 不存在"
        check_command mkswap "mkswap 可用"
        check_command swapon "swapon 可用"
        check_command swapoff "swapoff 可用"

        printf '\n[进程压制前提条件]\n'
        check_file_writable /proc/self/oom_score_adj "oom_score_adj 可写"
        check_file_readable /proc/pressure/memory "PSI memory 可读"
        check_file_readable /proc/pressure/cpu "PSI cpu 可读"
        check_file_readable /proc/pressure/io "PSI io 可读"
        [ -d /dev/cpuset ] && check_pass "/dev/cpuset 可用" || check_fail "/dev/cpuset 不可用"
        [ -d /sys/fs/cgroup ] && check_pass "/sys/fs/cgroup 可用" || check_fail "/sys/fs/cgroup 不可用"

        printf '\n[HTTP API 前提条件]\n'
        check_command cmd "cmd 命令可用 (通知/HTTP)"

        printf '\n[通知前提条件]\n'
        check_executable /system/bin/cmd "/system/bin/cmd 可执行"
        [ "$(id -u 2>/dev/null)" = "0" ] && check_pass "当前进程是 root" || check_fail "当前进程非 root"

        printf '\n[挂载/脚本前提条件]\n'
        check_command mount "mount 可用"
        check_command umount "umount 可用"
        for sh in service.sh action.sh uninstall.sh customize.sh; do
            check_executable "$MODDIR/$sh" "$MODDIR/$sh 可执行"
        done

        printf '\n[busybox applet 可用性]\n'
        if [ -n "$BB" ]; then
            for applet in tar grep sed awk find ps cat cut sort head tail wc ls stat dd chmod chown; do
                if "$BB" "$applet" --help >/dev/null 2>&1; then
                    check_pass "busybox $applet"
                else
                    check_fail "busybox $applet"
                fi
            done
        else
            check_fail "busybox 不可用，跳过 applet 检查"
        fi
    } > "$dest" 2>&1 || true
}

collect_device_info() {
    local dest="$STAGE/02_device_info.txt"
    {
        section "设备信息"

        printf '\n[型号与品牌]\n'
        getprop ro.product.model 2>/dev/null | sed 's/^/ro.product.model       = /'
        getprop ro.product.device 2>/dev/null | sed 's/^/ro.product.device      = /'
        getprop ro.product.name 2>/dev/null | sed 's/^/ro.product.name         = /'
        getprop ro.product.brand 2>/dev/null | sed 's/^/ro.product.brand        = /'
        getprop ro.product.manufacturer 2>/dev/null | sed 's/^/ro.product.manufacturer = /'
        getprop ro.vendor.product.model 2>/dev/null | sed 's/^/ro.vendor.product.model = /'
        getprop ro.vendor.product.device 2>/dev/null | sed 's/^/ro.vendor.product.device= /'

        printf '\n[Android 版本]\n'
        getprop ro.build.version.release 2>/dev/null | sed 's/^/ro.build.version.release = /'
        getprop ro.build.version.sdk 2>/dev/null | sed 's/^/ro.build.version.sdk     = /'
        getprop ro.build.version.security_patch 2>/dev/null | sed 's/^/ro.build.version.security_patch = /'
        getprop ro.build.id 2>/dev/null | sed 's/^/ro.build.id              = /'
        getprop ro.build.display.id 2>/dev/null | sed 's/^/ro.build.display.id      = /'
        getprop ro.build.fingerprint 2>/dev/null | sed 's/^/ro.build.fingerprint     = /'
        getprop ro.build.type 2>/dev/null | sed 's/^/ro.build.type             = /'
        getprop ro.build.tags 2>/dev/null | sed 's/^/ro.build.tags             = /'

        printf '\n[SoC / 硬件]\n'
        getprop ro.soc.model 2>/dev/null | sed 's/^/ro.soc.model  = /'
        getprop ro.soc.manufacturer 2>/dev/null | sed 's/^/ro.soc.manufacturer = /'
        getprop ro.hardware 2>/dev/null | sed 's/^/ro.hardware   = /'
        getprop ro.board.platform 2>/dev/null | sed 's/^/ro.board.platform = /'
        getprop ro.arch 2>/dev/null | sed 's/^/ro.arch       = /'

        printf '\n[CPU]\n'
        grep -m1 '^processor' /proc/cpuinfo 2>/dev/null | sed 's/^/cpuinfo首行 = /'
        grep -c '^processor' /proc/cpuinfo 2>/dev/null | sed 's/^/CPU核心数  = /'
        grep -m1 '^Hardware' /proc/cpuinfo 2>/dev/null | sed 's/^/Hardware    = /'
        grep -m1 '^model name' /proc/cpuinfo 2>/dev/null | sed 's/^/model name  = /'
        uname -m 2>/dev/null | sed 's/^/uname -m    = /'

        printf '\n[屏幕]\n'
        getprop ro.sf.lcd_density 2>/dev/null | sed 's/^/ro.sf.lcd_density = /'
        wm size 2>/dev/null | head -n1 | sed 's/^/wm size = /'
        wm density 2>/dev/null | head -n1 | sed 's/^/wm density = /'

        printf '\n[语言/时区]\n'
        getprop persist.sys.locale 2>/dev/null | sed 's/^/persist.sys.locale   = /'
        getprop persist.sys.language 2>/dev/null | sed 's/^/persist.sys.language = /'
        getprop persist.sys.country 2>/dev/null | sed 's/^/persist.sys.country  = /'
        getprop persist.sys.timezone 2>/dev/null | sed 's/^/persist.sys.timezone = /'
        date '+%Z %z' 2>/dev/null | sed 's/^/date TZ            = /'

        printf '\n[启动时间]\n'
        getprop ro.boottime 2>/dev/null | head -n3 | sed 's/^/ro.boottime = /'
        uptime 2>/dev/null | sed 's/^/uptime = /'
    } > "$dest" 2>&1 || true
}

collect_root_manager() {
    local dest="$STAGE/03_root_manager.txt"
    {
        section "Root 管理器检测"

        printf '\n[KernelSU]\n'
        [ -d /data/adb/ksu ] && check_pass "目录 /data/adb/ksu 存在" || check_fail "目录 /data/adb/ksu 不存在"
        [ -x /data/adb/ksu/bin/ksud ] && check_pass "ksud 可执行" || check_fail "ksud 不可执行"
        [ -x /data/adb/ksu/bin/busybox ] && check_pass "KSU busybox 可执行" || check_fail "KSU busybox 不可执行"
        getprop ksu.version 2>/dev/null | sed 's/^/ksu.version = /'
        getprop ksu.version_code 2>/dev/null | sed 's/^/ksu.version_code = /'

        printf '\n[APatch]\n'
        [ -d /data/adb/ap ] && check_pass "目录 /data/adb/ap 存在" || check_fail "目录 /data/adb/ap 不存在"
        [ -x /data/adb/ap/bin/apd ] && check_pass "apd 可执行" || check_fail "apd 不可执行"
        [ -x /data/adb/ap/bin/busybox ] && check_pass "APatch busybox 可执行" || check_fail "APatch busybox 不可执行"
        getprop apatch.version 2>/dev/null | sed 's/^/apatch.version = /'
        getprop apatch.version_code 2>/dev/null | sed 's/^/apatch.version_code = /'

        printf '\n[Magisk]\n'
        [ -d /data/adb/magisk ] && check_pass "目录 /data/adb/magisk 存在" || check_fail "目录 /data/adb/magisk 不存在"
        [ -x /data/adb/magisk/magisk ] && check_pass "magisk 可执行" || check_fail "magisk 不可执行"
        [ -x /data/adb/magisk/busybox ] && check_pass "Magisk busybox 可执行" || check_fail "Magisk busybox 不可执行"
        getprop magisk.version 2>/dev/null | sed 's/^/magisk.version = /'
        getprop magisk.versionCode 2>/dev/null | sed 's/^/magisk.versionCode = /'

        printf '\n[当前使用的 busybox]\n'
        if [ -n "$BB" ]; then
            printf 'path = %s\n' "$BB"
            printf '版本:\n'
            "$BB" 2>&1 | head -n3 | sed 's/^/  /'
            printf '\napplet 列表 (前80个):\n'
            "$BB" --list 2>/dev/null | head -n80 | sed 's/^/  /'
            printf '\napplet 总数 = %s\n' "$("$BB" --list 2>/dev/null | wc -l)"
        else
            printf 'busybox 不可用\n'
        fi

        printf '\n[SELinux 状态]\n'
        getenforce 2>/dev/null | sed 's/^/getenforce = /'
        cat /sys/fs/selinux/enforce 2>/dev/null | sed 's/^/enforce   = /' || printf 'enforce   = 不可读\n'
        id -Z 2>/dev/null | sed 's/^/scontext  = /' || printf 'scontext  = 不可读\n'
    } > "$dest" 2>&1 || true
}

collect_file_permissions() {
    local dest="$STAGE/04_file_permissions.txt"
    {
        section "文件权限"

        printf '\n[模块目录 %s]\n' "$MODDIR"
        ls_la_z "$MODDIR" 2>/dev/null | sed 's/^/  /'

        printf '\n[模块 scripts 目录]\n'
        ls_la_z "$MODDIR/scripts" 2>/dev/null | sed 's/^/  /'

        printf '\n[工作目录 %s]\n' "$WORKDIR"
        ls_la_z "$WORKDIR" 2>/dev/null | sed 's/^/  /'

        printf '\n[bin 目录 %s]\n' "$BIN_DIR"
        ls_la_z "$BIN_DIR" 2>/dev/null | sed 's/^/  /'

        printf '\n[关键文件 stat]\n'
        for f in \
            "$BIN_DIR/taskmild" \
            "$CONF_FILE" \
            "$LOG_FILE" \
            "$MODDIR/module.prop" \
            "$MODDIR/service.sh" \
            "$MODDIR/action.sh" \
            "$MODDIR/uninstall.sh" \
            "$MODDIR/customize.sh"
        do
            printf '\n--- %s ---\n' "$f"
            if [ -e "$f" ]; then
                stat -c '  mode=%a octal=%A uid=%u gid=%G size=%s bytes' "$f" 2>/dev/null || \
                "$BB" stat -c '  mode=%a uid=%u gid=%g size=%s' "$f" 2>/dev/null || \
                ls -la "$f" 2>/dev/null
            else
                printf '  文件不存在\n'
            fi
        done
    } > "$dest" 2>&1 || true
}

collect_auth_summary() {
    local dest="$STAGE/05_auth_summary.txt"
    {
        section "授权状态总结（纯本地信息，不联网）"

        printf '\n[设备序列号来源]\n'
        printf '\n--- /proc/bootconfig ---\n'
        grep -i 'serialno' /proc/bootconfig 2>/dev/null | head -n5 || printf '(不可读或无)\n'
        printf '\n--- device-tree ---\n'
        cat /proc/device-tree/firmware/android/serialno 2>/dev/null | tr -d '\0' | sed 's/^/serialno = /' || printf '(不可读)\n'
        printf '\n--- /proc/cmdline ---\n'
        cat /proc/cmdline 2>/dev/null | tr ' ' '\n' | grep -i 'serialno' | head -n3 || printf '(无 serialno 参数)\n'

        printf '\n[授权计数文件]\n'
        if [ -f "$DATA_DIR/auth_fail_count" ]; then
            cnt=$(cat "$DATA_DIR/auth_fail_count" 2>/dev/null || echo '?')
            printf 'auth_fail_count = %s (上限 9)\n' "$cnt"
        else
            printf 'auth_fail_count 文件不存在 (0/9)\n'
        fi

        printf '\n[停止标记 (stop_marker 存在=已熔断)]\n'
        if [ -f "$DATA_DIR/stop_marker" ]; then
            printf 'stop_marker 存在，模块已熔断\n'
            cat "$DATA_DIR/stop_marker" 2>/dev/null | sed 's/^/  /'
        else
            printf 'stop_marker 不存在，模块未熔断\n'
        fi

        printf '\n[崩溃计数]\n'
        if [ -f "$DATA_DIR/crash_count" ]; then
            printf 'crash_count = %s\n' "$(cat "$DATA_DIR/crash_count" 2>/dev/null || echo '?')"
        else
            printf 'crash_count 文件不存在\n'
        fi
        if [ -f "$DATA_DIR/crash_day" ]; then
            printf 'crash_day   = %s (今天=%s)\n' \
                "$(cat "$DATA_DIR/crash_day" 2>/dev/null || echo '?')" \
                "$(date '+%Y%m%d')"
        else
            printf 'crash_day 文件不存在\n'
        fi

        printf '\n[panic_flag]\n'
        if [ -f "$DATA_DIR/panic_flag" ]; then
            printf 'panic_flag 存在:\n'
            cat "$DATA_DIR/panic_flag" 2>/dev/null | head -n5 | sed 's/^/  /'
        else
            printf 'panic_flag 不存在\n'
        fi

        printf '\n[授权状态判断]\n'
        if [ -f "$DATA_DIR/stop_marker" ]; then
            printf '状态 = 已熔断（stop_marker 存在）\n'
        elif [ -f "$DATA_DIR/auth_fail_count" ]; then
            cnt=$(cat "$DATA_DIR/auth_fail_count" 2>/dev/null || echo 0)
            if [ "$cnt" -gt 0 ] 2>/dev/null; then
                printf '状态 = 验证中（失败 %s 次）\n' "$cnt"
            else
                printf '状态 = 正常（验证通过）\n'
            fi
        else
            printf '状态 = 正常（无失败记录）\n'
        fi
    } > "$dest" 2>&1 || true
}

collect_module_state() {
    local dest="$STAGE/module_state"
    mkdir -p "$dest" 2>/dev/null || true

    for f in run.log taskmild.conf module.prop panic_flag stop_marker \
             auth_fail_count crash_count crash_day bin/taskmild.pid \
             data/stats.txt data/license_agreed data/thermal_mounts.list \
             logs/thermal_bind.log; do
        local src=""
        case "$f" in
            module.prop) src="$MODDIR/module.prop" ;;
            run.log) src="$LOG_FILE" ;;
            taskmild.conf) src="$CONF_FILE" ;;
            *) src="$WORKDIR/$f" ;;
        esac
        if [ -r "$src" ]; then
            local flat_name=$(echo "$f" | sed 's|/|_|g')
            cp -f "$src" "$dest/$flat_name" 2>/dev/null || true
        fi
    done

    if [ -r "$LOG_FILE" ]; then
        tail -n 500 "$LOG_FILE" > "$dest/run.log.tail500" 2>/dev/null || true
    fi
}

collect_system_snapshot() {
    local dest="$STAGE/system_snapshot"
    mkdir -p "$dest" 2>/dev/null || true

    getprop > "$dest/getprop.txt" 2>&1 || true

    uname -a > "$dest/uname.txt" 2>&1 || true

    for f in version cmdline meminfo cpuinfo mounts loadavg filesystems slabinfo vmstat; do
        cat_to "/proc/$f" "$dest/proc_$f.txt"
    done

    mkdir -p "$dest/sys_vm" 2>/dev/null || true
    if [ -d /proc/sys/vm ]; then
        for f in /proc/sys/vm/*; do
            [ -r "$f" ] || continue
            bname=$(basename "$f")
            printf '%s = ' "$bname" > "$dest/sys_vm/$bname"
            cat "$f" >> "$dest/sys_vm/$bname" 2>/dev/null || printf '(不可读)\n' >> "$dest/sys_vm/$bname"
        done
    fi

    getenforce > "$dest/selinux_enforce.txt" 2>&1 || true
    cat_to /sys/fs/selinux/enforce "$dest/selinux_enforce_val.txt"
    cat_to /proc/self/attr/current "$dest/selinux_scontext.txt"

    if [ -n "$BB" ] && "$BB" dmesg >/dev/null 2>&1; then
        "$BB" dmesg 2>/dev/null | tail -n "$DMESG_TAIL" > "$dest/dmesg_tail.txt" || true
    elif command -v dmesg >/dev/null 2>&1; then
        dmesg 2>/dev/null | tail -n "$DMESG_TAIL" > "$dest/dmesg_tail.txt" || true
    else
        printf 'dmesg 不可用\n' > "$dest/dmesg_tail.txt"
    fi
}

collect_memory_pressure() {
    local dest="$STAGE/memory_pressure"
    mkdir -p "$dest" 2>/dev/null || true

    for p in memory cpu io; do
        cat_to "/proc/pressure/$p" "$dest/psi_$p.txt"
    done

    cat_to /sys/module/lowmemorykiller/parameters/minfree "$dest/lmk_minfree.txt"
    cat_to /sys/module/lowmemorykiller/parameters/thresholds "$dest/lmk_thresholds.txt"

    if [ -d /dev/cpuset ]; then
        ls_la_z /dev/cpuset > "$dest/cpuset_root.txt" 2>&1 || true
        for d in /dev/cpuset/*/; do
            [ -d "$d" ] || continue
            bname=$(basename "$d")
            {
                printf '=== %s ===\n' "$bname"
                cat "$d/cpus" 2>/dev/null | sed 's/^/cpus = /'
                cat "$d/mems" 2>/dev/null | sed 's/^/mems = /'
                cat "$d/tasks" 2>/dev/null | wc -l | sed 's/^/task_count = /'
            } > "$dest/cpuset_$bname.txt" 2>&1
        done
    fi

    if [ -d /sys/fs/cgroup ]; then
        ls -la /sys/fs/cgroup > "$dest/cgroup_v2_root.txt" 2>&1 || true
        cat_to /sys/fs/cgroup/cgroup.controllers "$dest/cgroup_v2_controllers.txt"
    fi

    cat_to /proc/self/oom_score_adj "$dest/self_oom_score_adj.txt"
}

collect_swap_zram() {
    local dest="$STAGE/swap_zram"
    mkdir -p "$dest" 2>/dev/null || true

    cat_to /proc/swaps "$dest/swaps.txt"
    cat_to /proc/meminfo "$dest/meminfo.txt"

    if [ -d /sys/block/zram0 ]; then
        mkdir -p "$dest/zram0" 2>/dev/null || true
        for attr in disksize compr_algorithm mem_used_total mem_limit \
                    reset idle_stats writeback_stats num_reads num_writes \
                    invalid_io concurrent_reads concurrent_writes; do
            f="/sys/block/zram0/$attr"
            if [ -r "$f" ]; then
                printf '%s = ' "$attr" > "$dest/zram0/$attr.txt"
                cat "$f" >> "$dest/zram0/$attr.txt" 2>/dev/null || printf '(不可读)\n' >> "$dest/zram0/$attr.txt"
            fi
        done
    fi

    mkdir -p "$dest/zswap" 2>/dev/null || true
    for f in /sys/module/zswap/parameters/*; do
        [ -r "$f" ] || continue
        bname=$(basename "$f")
        printf '%s = ' "$bname" > "$dest/zswap/$bname.txt"
        cat "$f" >> "$dest/zswap/$bname.txt" 2>/dev/null || printf '(不可读)\n' >> "$dest/zswap/$bname.txt"
    done

    swapon -s 2>/dev/null > "$dest/swapon_s.txt" || true
}

collect_thermal() {
    local dest="$STAGE/thermal"
    mkdir -p "$dest" 2>/dev/null || true

    if [ -r "$CONF_FILE" ]; then
        grep -E '^(thermal_enable|swap_enable)=' "$CONF_FILE" > "$dest/config_status.txt" 2>/dev/null || true
    fi

    if [ -d "$MODDIR/thermal_override" ]; then
        find "$MODDIR/thermal_override" -type f 2>/dev/null | wc -l > "$dest/staged_count.txt" || true
        ls -la "$MODDIR/thermal_override" > "$dest/staged_listing.txt" 2>/dev/null || true
    fi

    local mounted=0
    for d in system product system_ext; do
        if [ -d "$MODDIR/$d" ]; then
            local cnt
            cnt=$(find "$MODDIR/$d" -type f 2>/dev/null | wc -l)
            mounted=$((mounted + cnt))
        fi
    done
    echo "$mounted" > "$dest/mounted_count.txt" 2>/dev/null || true

    for d in system product system_ext; do
        if [ -d "$MODDIR/$d" ]; then
            ls -laR "$MODDIR/$d" > "$dest/mounted_${d}_listing.txt" 2>/dev/null || true
        fi
    done

    if [ -x "$MODDIR/scripts/tools.thermal-toggle.sh" ]; then
        "$MODDIR/scripts/tools.thermal-toggle.sh" --status > "$dest/toggle_status.txt" 2>&1 || true
        "$MODDIR/scripts/tools.thermal-toggle.sh" --json > "$dest/toggle_json.txt" 2>&1 || true
    fi

    if [ -x "$MODDIR/scripts/tools.thermal-check.sh" ]; then
        "$MODDIR/scripts/tools.thermal-check.sh" --json > "$dest/check_json.txt" 2>&1 || true
    fi

    {
        echo "=== Thermal Config ==="
        cat "$dest/config_status.txt" 2>/dev/null || echo "(config not readable)"
        echo ""
        echo "=== Staged (thermal_override/) ==="
        cat "$dest/staged_count.txt" 2>/dev/null || echo "0"
        echo ""
        echo "=== Mounted (system/product/system_ext) ==="
        cat "$dest/mounted_count.txt" 2>/dev/null || echo "0"
        echo ""
        echo "=== Toggle Status ==="
        cat "$dest/toggle_status.txt" 2>/dev/null || echo "(toggle script not available)"
    } > "$dest/summary.txt" 2>/dev/null || true
}

collect_network() {
    local dest="$STAGE/network"
    mkdir -p "$dest" 2>/dev/null || true

    if command -v ip >/dev/null 2>&1; then
        ip addr > "$dest/ip_addr.txt" 2>&1 || true
        ip route > "$dest/ip_route.txt" 2>&1 || true
    elif [ -n "$BB" ] && "$BB" ip addr >/dev/null 2>&1; then
        "$BB" ip addr > "$dest/ip_addr.txt" 2>&1 || true
        "$BB" ip route > "$dest/ip_route.txt" 2>&1 || true
    fi

    ifconfig 2>/dev/null > "$dest/ifconfig.txt" 2>&1 || true

    cat_to /etc/resolv.conf "$dest/resolv.conf.txt"
    getprop net.dns1 2>/dev/null > "$dest/dns1.txt" || true
    getprop net.dns2 2>/dev/null > "$dest/dns2.txt" || true

    {
        printf '=== gitee.com 连通性 ===\n'
        if command -v curl >/dev/null 2>&1; then
            curl -sS --connect-timeout 3 --max-time 5 -o /dev/null -w 'http_code=%{http_code} time=%{time_total}s\n' https://gitee.com 2>&1
        else
            printf 'curl 不可用\n'
        fi
        printf '\n=== DNS 解析 gitee.com ===\n'
        nslookup gitee.com 2>&1 | head -n10 || printf 'nslookup 不可用\n'
    } > "$dest/connectivity.txt" 2>&1 || true
}

collect_shell_env() {
    local dest="$STAGE/shell_env"
    mkdir -p "$dest" 2>/dev/null || true

    {
        section "命令可用性检查"
        for cmd in curl wget tar gzip grep sed awk find ps cat cut sort head tail \
                   wc ls stat dd chmod chown mount umount swapon swapoff mkswap \
                   getprop setprop cmd notify id uname date uptime free top \
                   ip ifconfig nslookup ping dmesg logcat; do
            if command -v "$cmd" >/dev/null 2>&1; then
                path=$(command -v "$cmd")
                printf '  [PASS] %-15s -> %s\n' "$cmd" "$path"
            else
                printf '  [FAIL] %s\n' "$cmd"
            fi
        done
    } > "$dest/commands.txt" 2>&1 || true

    printf '%s\n' "$PATH" > "$dest/PATH.txt" 2>&1 || true

    env 2>/dev/null | sort > "$dest/env.txt" 2>&1 || true

    if [ -n "$BB" ]; then
        {
            printf 'busybox path = %s\n' "$BB"
            printf '\n--- 版本 ---\n'
            "$BB" 2>&1 | head -n5
            printf '\n--- applet 列表 ---\n'
            "$BB" --list 2>/dev/null
        } > "$dest/busybox_info.txt" 2>&1 || true
    fi

    printf 'SHELL=%s\n' "${SHELL:-unset}" > "$dest/shell.txt" 2>&1 || true
    ls -la /system/bin/sh 2>/dev/null >> "$dest/shell.txt" || true
}

collect_processes() {
    local dest="$STAGE/processes_top30.txt"
    {
        section "Top $TOP_N 进程 (按 oom_score 降序)"
        printf '\n%-8s %-8s %-8s %-12s %s\n' "PID" "OOM" "OOM_ADJ" "RSS_KB" "CMDLINE"
        printf '%s\n' "----------------------------------------"

        tmp=$(mktemp 2>/dev/null) || tmp="$DIAG_DIR/.proc_$$.tmp"
        : > "$tmp" 2>/dev/null
        for pd in /proc/[0-9]*; do
            [ -d "$pd" ] || continue
            pid=${pd##*/}
            oom=$(cat "$pd/oom_score" 2>/dev/null || echo "0")
            adj=$(cat "$pd/oom_score_adj" 2>/dev/null || echo "?")
            rss=$(grep -m1 VmRSS "$pd/status" 2>/dev/null | awk '{print $2}')
            [ -z "$rss" ] && rss="0"
            cmd=$(tr '\0' ' ' < "$pd/cmdline" 2>/dev/null | cut -c1-80)
            [ -z "$cmd" ] && cmd=$(cat "$pd/comm" 2>/dev/null || echo "?")
            printf '%s\t%s\t%s\t%s\t%s\n' "$pid" "$oom" "$adj" "$rss" "$cmd" >> "$tmp"
        done

        if [ -n "$BB" ]; then
            "$BB" sort -t$'\t' -k2 -n -r "$tmp" 2>/dev/null | head -n "$TOP_N" | \
            while IFS=$(printf '\t') read -r pid oom adj rss cmd; do
                printf '%-8s %-8s %-8s %-12s %s\n' "$pid" "$oom" "$adj" "$rss" "$cmd"
            done
        else
            sort -t$'\t' -k2 -n -r "$tmp" 2>/dev/null | head -n "$TOP_N" | \
            while IFS=$(printf '\t') read -r pid oom adj rss cmd; do
                printf '%-8s %-8s %-8s %-12s %s\n' "$pid" "$oom" "$adj" "$rss" "$cmd"
            done
        fi
        rm -f "$tmp" 2>/dev/null || true
    } > "$dest" 2>&1 || true
}

collect_scheduler_probe() {
    local dest="$STAGE/15_scheduler_probe.txt"
    local taskmild_pid=""

    for pd in /proc/[0-9]*; do
        [ -d "$pd" ] || continue
        local comm
        comm=$(cat "$pd/comm" 2>/dev/null || echo "")
        if [ "$comm" = "taskmild" ] || [ "$comm" = "TaskMild" ]; then
            taskmild_pid=${pd##*/}
            break
        fi
    done

    {
        section "TaskMild 调度器存活探针"

        printf '\n[模块版本]\n'
        printf 'module.prop version    = %s\n' "$(grep '^version=' "$MODDIR/module.prop" 2>/dev/null | cut -d= -f2)"
        printf 'module.prop versionCode= %s\n' "$(grep '^versionCode=' "$MODDIR/module.prop" 2>/dev/null | cut -d= -f2)"
        printf '二进制版本 (strings)   = %s\n' "$(strings "$BIN_DIR/taskmild" 2>/dev/null | grep -m1 -E '^[0-9]{8}$' || echo '?')"

        printf '\n[守护进程 PID]\n'
        if [ -n "$taskmild_pid" ]; then
            printf 'taskmild PID = %s\n' "$taskmild_pid"
            printf '进程状态     = %s\n' "$(cat /proc/$taskmild_pid/status 2>/dev/null | grep '^State:' | awk '{print $2, $3}')"
            printf '启动时间     = %s\n' "$(stat -c %y /proc/$taskmild_pid 2>/dev/null | cut -d. -f1)"
            printf '运行时长(秒) = %s\n' "$(awk '{print int($1)}' /proc/$taskmild_pid/stat 2>/dev/null | head -1 || echo '?')"
        else
            printf 'taskmild 进程未找到 (可能未启动)\n'
        fi

        printf '\n[线程状态与 CPU 占用]\n'
        if [ -n "$taskmild_pid" ]; then
            printf '%-20s %-8s %-8s %s\n' "线程名" "TID" "CPU%" "状态"
            printf '%s\n' "------------------------------------------------"
            for task in /proc/$taskmild_pid/task/*; do
                [ -d "$task" ] || continue
                local tid=${task##*/}
                local tname
                tname=$(cat "$task/comm" 2>/dev/null || echo "?")
                local tstate
                tstate=$(cat "$task/status" 2>/dev/null | grep '^State:' | awk '{print $2}')
                local ticks
                ticks=$(awk '{print $14+$15}' "$task/stat" 2>/dev/null || echo "0")
                local cpu_pct="0.0"
                local total_ticks
                total_ticks=$(awk '{print $14+$15}' /proc/$taskmild_pid/stat 2>/dev/null || echo "1")
                [ "$total_ticks" -gt 0 ] 2>/dev/null && cpu_pct=$(awk "BEGIN{printf \"%.1f\", ($ticks/$total_ticks)*100}")
                printf '%-20s %-8s %-8s %s\n' "$tname" "$tid" "$cpu_pct" "$tstate"
            done
        else
            printf '(taskmild 进程未启动, 跳过线程状态)\n'
        fi

        printf '\n[日志级别生效值]\n'
        printf '配置文件 log_level     = %s\n' "$(grep '^log_level=' "$CONF_FILE" 2>/dev/null | cut -d= -f2 || echo '?')"
        printf '配置文件 log.format    = %s\n' "$(grep '^log.format=' "$CONF_FILE" 2>/dev/null | cut -d= -f2 || echo '?')"
        if [ -f "$LOG_FILE" ]; then
            local total_lines
            total_lines=$(wc -l < "$LOG_FILE" 2>/dev/null || echo "0")
            printf 'run.log 总行数         = %s\n' "$total_lines"
            printf '\n最近 100 行日志级别分布:\n'
            tail -100 "$LOG_FILE" 2>/dev/null | grep -o '"level":"[^"]*"' | sort | uniq -c | sort -rn | sed 's/^/  /'
            printf '\n最近 5 行日志:\n'
            tail -5 "$LOG_FILE" 2>/dev/null | sed 's/^/  /'
        else
            printf 'run.log 不存在\n'
        fi

        printf '\n[调度器活动最近时间戳]\n'
        if [ -f "$LOG_FILE" ]; then
            local last_press_ts
            last_press_ts=$(grep -E 'v74|压制|press_background|优雅杀|SIGTERM|SIGKILL' "$LOG_FILE" 2>/dev/null | tail -1 | grep -o '"ts":"[^"]*"' | cut -d'"' -f4)
            printf '最近一次压制活动时间戳 = %s\n' "${last_press_ts:-无记录}"
            local last_watchdog_ts
            last_watchdog_ts=$(grep -E '看门狗|watchdog' "$LOG_FILE" 2>/dev/null | tail -1 | grep -o '"ts":"[^"]*"' | cut -d'"' -f4)
            printf '最近一次看门狗活动时间 = %s\n' "${last_watchdog_ts:-无记录}"
            printf '当前时间               = %s\n' "$(date '+%Y-%m-%dT%H:%M:%S%z')"
            if [ -n "$last_press_ts" ]; then
                local last_epoch now_epoch
                last_epoch=$(date -d "$last_press_ts" '+%s' 2>/dev/null || echo "0")
                now_epoch=$(date '+%s')
                if [ "$last_epoch" -gt 0 ] 2>/dev/null; then
                    local stalled=$((now_epoch - last_epoch))
                    printf '压制活动停摆时长(秒)   = %s\n' "$stalled"
                    if [ "$stalled" -gt 900 ]; then
                        printf '  [警告] 停摆超过 900 秒阈值, 调度器可能已失效\n'
                    fi
                fi
            fi
        else
            printf 'run.log 不存在, 无法探测调度器活动\n'
        fi
    } > "$dest" 2>&1 || true
}

package_and_rotate() {
    cd "$DIAG_DIR" 2>/dev/null || return 1

    if [ -n "$BB" ]; then
        "$BB" tar -czf "$OUT_FILE" -C "$DIAG_DIR" "$(basename "$STAGE")" 2>/dev/null
    fi
    if [ ! -s "$OUT_FILE" ]; then
        tar -czf "$OUT_FILE" -C "$DIAG_DIR" "$(basename "$STAGE")" 2>/dev/null
    fi
    if [ ! -s "$OUT_FILE" ]; then
        local fallback="${OUT_FILE%.tar.gz}.tar"
        if [ -n "$BB" ]; then
            "$BB" tar -cf "$fallback" -C "$DIAG_DIR" "$(basename "$STAGE")" 2>/dev/null
        else
            tar -cf "$fallback" -C "$DIAG_DIR" "$(basename "$STAGE")" 2>/dev/null
        fi
    fi

    rm -rf "$STAGE" 2>/dev/null || true

    if [ -n "$BB" ]; then
        "$BB" ls -t "$DIAG_DIR"/diag_*.tar.* 2>/dev/null | awk -v max="$MAX_ARCHIVES" 'NR>max{print}' | while IFS= read -r f; do
            rm -f "$f" 2>/dev/null || true
        done
    else
        ls -t "$DIAG_DIR"/diag_*.tar.* 2>/dev/null | awk -v max="$MAX_ARCHIVES" 'NR>max{print}' | while IFS= read -r f; do
            rm -f "$f" 2>/dev/null || true
        done
    fi
}

send_notification() {
    local file_path="$1"
    local file_size="?"
    if [ -f "$file_path" ]; then
        local bytes
        bytes=$(stat -c %s "$file_path" 2>/dev/null || wc -c < "$file_path" 2>/dev/null || echo 0)
        if [ -n "$bytes" ] && [ "$bytes" -gt 0 ] 2>/dev/null; then
            if [ "$bytes" -ge 1048576 ]; then
                file_size=$((bytes / 1048576))"MB"
            else
                file_size=$((bytes / 1024))"KB"
            fi
        fi
    fi

    local title="TaskMild 诊断报告"
    local text="诊断包已保存: $file_path ($file_size)"

    if command -v cmd >/dev/null 2>&1; then
        cmd notification post --title "$title" --text "$text" "taskmild_diag" 2>/dev/null && return 0
    fi

    if [ -x /system/bin/cmd ]; then
        /system/bin/cmd statusbar notify -t "$title" -m "$text" 2>/dev/null && return 0
    fi

    printf '[%s] [信息] [diag] 诊断包已保存: %s (%s)\n' \
        "$(date '+%Y-%m-%d %H:%M:%S')" "$file_path" "$file_size" >> "$LOG_FILE" 2>/dev/null || true
}

main() {
    mkdir -p "$DIAG_DIR" 2>/dev/null || true
    mkdir -p "$STAGE" 2>/dev/null || true

    printf '[%s] [信息] [diag] 开始收集诊断信息 (pid=%s, busybox=%s)\n' \
        "$(date '+%Y-%m-%d %H:%M:%S')" "$$" "${BB:-无}" >> "$LOG_FILE" 2>/dev/null || true

    local reason_arg="${1:-}"
    collect_error_context "$reason_arg"
    collect_precondition_checks
    collect_device_info
    collect_root_manager
    collect_file_permissions
    collect_auth_summary
    collect_module_state
    collect_system_snapshot
    collect_memory_pressure
    collect_swap_zram
    collect_thermal
    collect_network
    collect_shell_env
    collect_processes
    collect_scheduler_probe

    package_and_rotate

    if [ -s "$OUT_FILE" ]; then
        printf '[%s] [信息] [diag] 诊断包已生成: %s\n' \
            "$(date '+%Y-%m-%d %H:%M:%S')" "$OUT_FILE" >> "$LOG_FILE" 2>/dev/null || true
        send_notification "$OUT_FILE"
        echo "$OUT_FILE"
        return 0
    else
        printf '[%s] [错误] [diag] 诊断包生成失败\n' \
            "$(date '+%Y-%m-%d %H:%M:%S')" >> "$LOG_FILE" 2>/dev/null || true
        echo "" >&2
        return 1
    fi
}

main "$@"
