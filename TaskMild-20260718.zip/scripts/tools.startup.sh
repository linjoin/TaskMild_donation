#!/system/bin/sh

set -u

MODDIR=${0%/*}
MODDIR=$(readlink -f "$MODDIR" 2>/dev/null || echo "$MODDIR")

. "$MODDIR/tools.sh"

import_config() {
    conf="/data/adb/taskmild/taskmild.conf"
    if [ -f "$conf" ]; then
        swap_enable=$(read_config_value swap_enable)
        swap=$(read_config_value swap)
        swap_size=$(read_config_value swap_size)
        swap_priority=$(read_config_value swap_priority)
        swap_use_loop=$(read_config_value swap_use_loop)
        zram=$(read_config_value zram)
        zram_size=$(read_config_value zram_size)
        comp_algorithm=$(read_config_value comp_algorithm)
        zram_writeback=$(read_config_value zram_writeback)
        swappiness=$(read_config_value swappiness)
        extra_free_kbytes=$(read_config_value extra_free_kbytes)
        watermark_scale_factor=$(read_config_value watermark_scale_factor)
        daemon_service=$(read_config_value daemon_service)
        daemon_used_limit=$(read_config_value daemon_used_limit)
    fi
    : "${swap_enable:=on}"
    : "${swap:=false}"
    : "${swap_size:=}"
    : "${swap_priority:=}"
    : "${swap_use_loop:=}"
    : "${zram:=false}"
    : "${zram_size:=}"
    : "${comp_algorithm:=}"
    : "${zram_writeback:=false}"
    : "${swappiness:=}"
    : "${extra_free_kbytes:=}"
    : "${watermark_scale_factor:=}"
    : "${daemon_service:=off}"
    : "${daemon_used_limit:=}"
    export swap_enable swap swap_size swap_priority swap_use_loop
    export zram zram_size comp_algorithm zram_writeback swappiness
    export extra_free_kbytes watermark_scale_factor daemon_service daemon_used_limit
    [ -f "$conf" ] || return 1
    return 0
}

init_group() {
    g="/dev/memcg/$1"
    if [ ! -d "$g" ]; then
        mkdir -p "$g"
    fi
    echo "$2" > "$g/memory.swappiness" 2>/dev/null || true
    echo 1 > "$g/memory.use_hierarchy" 2>/dev/null || true
    if [ "$2" -le 30 ]; then
        set_value 0 "$g/memory.anno_writeback_enable"
    else
        set_value 1 "$g/memory.anno_writeback_enable"
    fi
    echo 1 > "$g/memory.move_charge_at_immigrate" 2>/dev/null || true
    echo 1 > "$g/memory.oom_control" 2>/dev/null || true
}
