#!/system/bin/sh

MODDIR=${0%/*}
MODDIR=$(readlink -f "$MODDIR" 2>/dev/null || echo "$MODDIR")

apply_xiaomi_tuning() {
  if [ -f /proc/sys/vm/swappiness ]; then
    echo 60 > /proc/sys/vm/swappiness 2>/dev/null
  fi
  if [ -f /proc/sys/vm/extra_free_kbytes ]; then
    echo 8192 > /proc/sys/vm/extra_free_kbytes 2>/dev/null
  fi
  if [ -f /proc/sys/vm/watermark_scale_factor ]; then
    echo 20 > /proc/sys/vm/watermark_scale_factor 2>/dev/null
  fi
  for f in /sys/module/mi_thermald/parameters/*; do
    if [ -f "$f" ]; then
      bn=$(basename "$f")
      case "$bn" in
        enabled)
          echo 0 > "$f" 2>/dev/null
          ;;
      esac
    fi
  done
  if [ -d /sys/kernel/mm/athena ]; then
    echo 0 > /sys/kernel/mm/athena/enable 2>/dev/null
  fi
}

apply_xiaomi_tuning
