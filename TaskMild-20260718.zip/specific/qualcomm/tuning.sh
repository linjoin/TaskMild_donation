#!/system/bin/sh

MODDIR=${0%/*}
MODDIR=$(readlink -f "$MODDIR" 2>/dev/null || echo "$MODDIR")

apply_qualcomm_tuning() {
  if [ -f /proc/sys/vm/swappiness ]; then
    echo 60 > /proc/sys/vm/swappiness 2>/dev/null
  fi
  if [ -f /proc/sys/vm/extra_free_kbytes ]; then
    echo 4096 > /proc/sys/vm/extra_free_kbytes 2>/dev/null
  fi
  if [ -f /proc/sys/vm/watermark_scale_factor ]; then
    echo 15 > /proc/sys/vm/watermark_scale_factor 2>/dev/null
  fi
  for f in /sys/module/msm_thermal/parameters/*; do
    if [ -f "$f" ]; then
      bn=$(basename "$f")
      case "$bn" in
        enabled)
          echo 0 > "$f" 2>/dev/null
          ;;
      esac
    fi
  done
  if [ -f /sys/module/lpm_levels/parameters/sleep_msec ]; then
    echo 100 > /sys/module/lpm_levels/parameters/sleep_msec 2>/dev/null
  fi
}

apply_qualcomm_tuning
