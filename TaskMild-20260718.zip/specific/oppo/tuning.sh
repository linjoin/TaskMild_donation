#!/system/bin/sh

MODDIR=${0%/*}
MODDIR=$(readlink -f "$MODDIR" 2>/dev/null || echo "$MODDIR")

apply_oppo_tuning() {
  if [ -f /proc/sys/vm/swappiness ]; then
    echo 60 > /proc/sys/vm/swappiness 2>/dev/null
  fi
  if [ -f /proc/sys/vm/extra_free_kbytes ]; then
    echo 16384 > /proc/sys/vm/extra_free_kbytes 2>/dev/null
  fi
  if [ -f /proc/sys/vm/watermark_scale_factor ]; then
    echo 40 > /proc/sys/vm/watermark_scale_factor 2>/dev/null
  fi
  for f in /sys/module/process_mng/parameters/*; do
    if [ -f "$f" ]; then
      bn=$(basename "$f")
      case "$bn" in
        bg_apps_limit)
          echo 64 > "$f" 2>/dev/null
          ;;
        swap_enable)
          echo 1 > "$f" 2>/dev/null
          ;;
      esac
    fi
  done
  if [ -d /sys/kernel/mm/color_bulk ]; then
    echo 0 > /sys/kernel/mm/color_bulk/enable 2>/dev/null
  fi
}

apply_oppo_tuning
