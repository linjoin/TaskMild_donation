#!/system/bin/sh

readonly WORKDIR="/data/adb/taskmild"
readonly BIN="$WORKDIR/bin/taskmild"
readonly LOCK_DIR="$WORKDIR/lock"
readonly LOGS_DIR="$WORKDIR/logs"
readonly DATA_DIR="$WORKDIR/data"
readonly PID_FILE="$LOCK_DIR/taskmild.pid"
readonly STOP_MARKER="$DATA_DIR/stop_marker"
readonly LOG_FILE="$LOGS_DIR/run.log"

MODDIR="${0%/*}"
MODDIR=$(readlink -f "$MODDIR" 2>/dev/null || echo "$MODDIR")
MODULE_PROP="$MODDIR/module.prop"

mkdir -p "$LOGS_DIR" "$LOCK_DIR" "$DATA_DIR" 2>/dev/null || true

log_info() {
    printf '[%s] [信息] %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$1" >> "$LOG_FILE" 2>/dev/null || true
}

log_warn() {
    printf '[%s] [警告] %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$1" >> "$LOG_FILE" 2>/dev/null || true
}

log_error() {
    printf '[%s] [错误] %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$1" >> "$LOG_FILE" 2>/dev/null || true
}

update_module_desc() {
    _desc="$1"
    [ -f "$MODULE_PROP" ] || return 0
    _cur=$(sed -n 's|^description=||p' "$MODULE_PROP" 2>/dev/null | head -n1)
    [ "$_cur" = "$_desc" ] && return 0
    sed -i "s|^description=.*|description=$_desc|" "$MODULE_PROP" 2>/dev/null || true
    log_info "module.prop description 已更新: $_desc"
}

check_running() {
    if [ -f "$PID_FILE" ]; then
        pid=$(cat "$PID_FILE" 2>/dev/null) || true
        if [ -n "$pid" ] && [ -d "/proc/$pid" ]; then
            if [ -f "/proc/$pid/cmdline" ]; then
                cmdline=$(cat "/proc/$pid/cmdline" 2>/dev/null | tr '\0' ' ') || true
                case "$cmdline" in
                    *taskmild*|*Taskmild*) return 0 ;;
                esac
            fi
        fi
    fi
    pidof taskmild >/dev/null 2>&1 && return 0
    return 1
}

do_stop() {
    touch "$STOP_MARKER" 2>/dev/null || true

    if [ -f "$PID_FILE" ]; then
        pid=$(cat "$PID_FILE" 2>/dev/null) || true
        if [ -n "$pid" ] && [ -d "/proc/$pid" ]; then
            kill "$pid" 2>/dev/null || true
            sleep 1
            [ -d "/proc/$pid" ] && kill -9 "$pid" 2>/dev/null || true
        fi
    fi

    killall taskmild 2>/dev/null || true
    rm -f "$PID_FILE" 2>/dev/null || true

    update_module_desc "未启动"

    log_info "TaskMild 已停止"
    printf '%s\n' "TaskMild 已停止"
}

do_start() {
    rm -f "$STOP_MARKER" 2>/dev/null || true

    if [ ! -x "$BIN" ]; then
        log_error "TaskMild 二进制文件不存在"
        update_module_desc "启动失败"
        printf '%s\n' "TaskMild 二进制文件不存在，无法启动"
        return 1
    fi

    nohup "$BIN" run >> /dev/null 2>&1 &
    sleep 2

    if check_running; then
        pid=$(cat "$PID_FILE" 2>/dev/null || echo "unknown")
        update_module_desc "运行中"
        log_info "TaskMild 已启动 PID=${pid}"
        printf '%s\n' "TaskMild 已启动 (PID=${pid})"
    else
        sleep 1
        nohup "$BIN" run >> /dev/null 2>&1 &
        sleep 2
        if check_running; then
            pid=$(cat "$PID_FILE" 2>/dev/null || echo "unknown")
            update_module_desc "运行中"
            log_info "TaskMild 已启动 PID=${pid}"
            printf '%s\n' "TaskMild 已启动 (PID=${pid})"
        else
            log_error "TaskMild 启动失败"
            update_module_desc "启动失败"
            printf '%s\n' "TaskMild 启动失败，请检查日志"
            return 1
        fi
    fi
}

if [ "${1:-}" = "thermal-check" ] || [ "${1:-}" = "check-thermal" ]; then
    THERMAL_CHECK="$MODDIR/scripts/tools.thermal-check.sh"
    if [ -x "$THERMAL_CHECK" ]; then
        "$THERMAL_CHECK"
        exit $?
    else
        printf '%s\n' "! 温控自检脚本不存在: $THERMAL_CHECK"
        exit 2
    fi
fi

if [ "${1:-}" = "thermal-toggle" ] || [ "${1:-}" = "toggle-thermal" ]; then
    THERMAL_TOGGLE="$MODDIR/scripts/tools.thermal-toggle.sh"
    if [ -x "$THERMAL_TOGGLE" ]; then
        shift
        "$THERMAL_TOGGLE" "${1:-}"
        exit $?
    else
        printf '%s\n' "! 温控开关脚本不存在: $THERMAL_TOGGLE"
        exit 2
    fi
fi

if check_running; then
    do_stop
else
    do_start
fi
