#!/system/bin/sh

set -u

SKIPUNZIP=1

: "${REPLACE:=}"
: "${skipMOUNT:=}"
: "${PROPFILE:=}"
: "${POSTFSDATA:=}"
: "${LATESTARTSERVICE:=}"

: "${MODPATH:=}"
: "${ZIPFILE:=}"

if [ -z "$MODPATH" ]; then
    MODPATH="/data/adb/modules/taskmild"
    mkdir -p "$MODPATH" 2>/dev/null || true
fi
if ! command -v abort >/dev/null 2>&1; then
    abort() {
        ui_print "! $1" 2>/dev/null || echo "! $1"
        ui_print "! Installation aborted" 2>/dev/null || echo "! Installation aborted"
        exit 1
    }
fi

language="zh"

locale=$(getprop persist.sys.locale 2>/dev/null || getprop ro.product.locale 2>/dev/null || getprop persist.sys.language 2>/dev/null)
if echo "$locale" | grep -qi "en"; then
    language="en"
fi

info() {
    [ "$language" = "en" ] && ui_print "$1" || ui_print "$2"
}

error() {
    [ "$language" = "en" ] && abort "$1" || abort "$2"
}

readonly WORKDIR="/data/adb/taskmild"
readonly BINDIR="$WORKDIR/bin"
readonly BIN="$BINDIR/taskmild"
readonly CONF="$WORKDIR/config/taskmild.conf"
readonly DATA_DIR="$WORKDIR/data"
readonly CHOICE_TIMEOUT_SECS=15

NEW_VERSION="$(unzip -p "$ZIPFILE" module.prop 2>/dev/null | grep '^version=' | cut -d= -f2)" || true
NEW_VERSIONCODE="$(unzip -p "$ZIPFILE" module.prop 2>/dev/null | grep '^versionCode=' | cut -d= -f2)" || true
NEW_VERSION="${NEW_VERSION#v}"
OLD_VERSION=""
OLD_VERSIONCODE=""
[ -f "/data/adb/modules/taskmild/module.prop" ] && {
    OLD_VERSION="$(grep '^version=' /data/adb/modules/taskmild/module.prop 2>/dev/null | cut -d= -f2)" || true
    OLD_VERSIONCODE="$(grep '^versionCode=' /data/adb/modules/taskmild/module.prop 2>/dev/null | cut -d= -f2)" || true
    OLD_VERSION="${OLD_VERSION#v}"
}

SDK_VERSION=$(getprop ro.build.version.sdk)
KERNEL_VERSION=$(uname -r | cut -d'-' -f1)
KERNEL_VERSION_1=$(echo "$KERNEL_VERSION" | cut -d'.' -f1)
PLATFORM=$(getprop ro.board.platform)
SOC=$(getprop ro.soc.model 2>/dev/null | tr '[:lower:]' '[:upper:]')
MEM_TOTAL_STR=$(grep MemTotal /proc/meminfo)
MEM_TOTAL_KB=$(echo "$MEM_TOTAL_STR" | awk '{print $2}')
MEM_TOTAL_GB=$(((MEM_TOTAL_KB / 1024 + 2047) / 2048 * 2))

DEVICE_MODEL="$(getprop ro.product.model 2>/dev/null)" || true

detect_root_manager() {
    if [ -d /data/adb/ksu ] || [ -n "$(getprop ksu.version 2>/dev/null)" ]; then
        echo "ksu"
        return 0
    fi
    if [ -d /data/adb/ap ] || [ -n "$(getprop apatch.version 2>/dev/null)" ]; then
        echo "apatch"
        return 0
    fi
    if [ -d /data/adb/magisk ] || [ -n "$(getprop magisk.version 2>/dev/null)" ] || command -v magisk >/dev/null 2>&1; then
        echo "magisk"
        return 0
    fi
    echo "unknown"
    return 1
}

ROOT_MANAGER="$(detect_root_manager 2>/dev/null || echo unknown)"

mkdir -p "$DATA_DIR" 2>/dev/null || true
touch "$DATA_DIR/stop_marker" 2>/dev/null || true

info "Stopping old process..." "正在停止旧进程..."
stop_taskmild() {
    _pidfile="/data/adb/taskmild/lock/taskmild.pid"
    [ -f "$_pidfile" ] || return 0
    _pid=$(cat "$_pidfile" 2>/dev/null) || return 0
    [ -n "$_pid" ] || return 0
    [ -d "/proc/$_pid" ] || { rm -f "$_pidfile" 2>/dev/null || true; return 0; }
    _cmd=$(cat "/proc/$_pid/cmdline" 2>/dev/null | tr '\0' ' ')
    case "$_cmd" in
        *taskmild*|*Taskmild*) kill -9 "$_pid" 2>/dev/null || true ;;
    esac
    rm -f "$_pidfile" 2>/dev/null || true
}
stop_taskmild

pkill -9 -f 'taskmild-cleanup' 2>/dev/null || true

pkill -9 -f 'taskmild.*service\.sh' 2>/dev/null || true

rm -f "$BINDIR/taskmild.pid" 2>/dev/null || true
info "Old process stopped" "旧进程已停止"

info "Installing TaskMild v${NEW_VERSION}" "正在安装 TaskMild v${NEW_VERSION}"

if [ -n "$OLD_VERSION" ]; then
    info "Upgrade: v$OLD_VERSION → v$NEW_VERSION" "升级: v$OLD_VERSION → v$NEW_VERSION"
else
    info "Fresh install" "全新安装"
fi
info "Device: $DEVICE_MODEL | ${MEM_TOTAL_GB}GB | $SOC | SDK $SDK_VERSION" "设备: $DEVICE_MODEL | ${MEM_TOTAL_GB}GB | $SOC | SDK $SDK_VERSION"

case "$ROOT_MANAGER" in
    ksu)    info "Root: KernelSU" "Root: KernelSU" ;;
    apatch) info "Root: APatch" "Root: APatch" ;;
    magisk) info "Root: Magisk" "Root: Magisk" ;;
    *)      info "Root: Unknown (may not work!)" "Root: 未知 (可能不兼容!)" ;;
esac

ARCH="$(uname -m 2>/dev/null || echo unknown)"
case "$ARCH" in
    aarch64|arm64) : ;;
    *)
        error "Unsupported arch: $ARCH (this module ships arm64-v8a only, need aarch64)" "不支持的架构: $ARCH (本模块仅打包 arm64-v8a 二进制, 需 aarch64 设备)"
        ;;
esac
info "Arch: $ARCH" "架构: $ARCH"

info "Extracting module files..." "正在解压模块文件..."
unzip -o "$ZIPFILE" module.prop customize.sh service.sh action.sh uninstall.sh -d "$MODPATH" >/dev/null 2>&1
unzip -o "$ZIPFILE" 'payload/*' -d "$MODPATH" >/dev/null 2>&1
unzip -o "$ZIPFILE" 'scripts/*' -d "$MODPATH" >/dev/null 2>&1
unzip -o "$ZIPFILE" 'specific/*' -d "$MODPATH" >/dev/null 2>&1
unzip -o "$ZIPFILE" 'athena/*' -d "$MODPATH" >/dev/null 2>&1
unzip -o "$ZIPFILE" 'osense/*' -d "$MODPATH" >/dev/null 2>&1
unzip -o "$ZIPFILE" 'system*.prop' -d "$MODPATH" >/dev/null 2>&1
rm -rf "$MODPATH/webroot" 2>/dev/null || true
unzip -o "$ZIPFILE" 'webroot/*' -d "$MODPATH" >/dev/null 2>&1
info "Module files extracted" "模块文件解压完成"

THERMAL_OVERRIDE_COUNT=0
THERMAL_STAGED=0
if unzip -l "$ZIPFILE" 'thermal_override/*' 2>/dev/null | grep -q 'thermal_override/'; then
    info "Extracting thermal override..." "正在解压温控屏蔽文件..."
    unzip -o "$ZIPFILE" 'thermal_override/*' -d "$MODPATH" >/dev/null 2>&1
    if [ -d "$MODPATH/thermal_override" ]; then
        THERMAL_STAGED=$(find "$MODPATH/thermal_override" -type f 2>/dev/null | wc -l)
        info "Thermal override: $THERMAL_STAGED files staged" "温控屏蔽: $THERMAL_STAGED 个空文件已暂存"
    fi
else
    info "Thermal override: not bundled" "温控屏蔽: 未内置 (跳过)"
fi

MODULE_CONF="$MODPATH/payload/taskmild.conf"

readonly CONFIG_DIR="$WORKDIR/config"
readonly LOCK_DIR="$WORKDIR/lock"
readonly LOGS_DIR="$WORKDIR/logs"
mkdir -p "$WORKDIR" "$BINDIR" "$CONFIG_DIR" "$LOCK_DIR" "$LOGS_DIR" "$DATA_DIR"

if [ -f "$MODPATH/payload/taskmild" ]; then
    info "Installing binary..." "正在安装二进制文件..."
    cp -af "$MODPATH/payload/taskmild" "$BIN"
    if [ -f "$BIN" ]; then
        _binsz=$(stat -c %s "$BIN" 2>/dev/null || echo 0)
        if [ "$_binsz" -lt 100000 ]; then
            error "Binary too small ($_binsz bytes), possibly corrupted!" "二进制过小($_binsz 字节), 可能损坏!"
        fi
        chmod 0755 "$BIN"
        info "Binary installed ($_binsz bytes)" "二进制文件安装完成 ($_binsz 字节)"
    else
        error "Binary copy failed!" "二进制文件复制失败!"
    fi
else
    error "Binary not found!" "二进制文件未找到！"
fi

CLEANUP_BIN="$BINDIR/taskmild-cleanup"
if [ -f "$MODPATH/payload/taskmild-cleanup" ]; then
    info "Installing cleanup binary..." "正在安装清理子进程二进制..."
    cp -af "$MODPATH/payload/taskmild-cleanup" "$CLEANUP_BIN"
    if [ -f "$CLEANUP_BIN" ]; then
        _clnsz=$(stat -c %s "$CLEANUP_BIN" 2>/dev/null || echo 0)
        if [ "$_clnsz" -lt 500000 ]; then
            error "Cleanup binary too small ($_clnsz bytes), possibly corrupted!" "清理二进制过小($_clnsz 字节), 可能损坏!"
        fi
        chmod 0755 "$CLEANUP_BIN"
        info "Cleanup binary installed ($_clnsz bytes)" "清理子进程安装完成 ($_clnsz 字节)"
    else
        error "Cleanup binary copy failed!" "清理子进程复制失败!"
    fi
else
    info "Cleanup binary not found (degraded mode)" "清理子进程未找到 (降级模式)"
fi

migrate_v944_paths() {
    if [ -f "$WORKDIR/taskmild.conf" ] && [ ! -f "$CONFIG_DIR/taskmild.conf" ]; then
        mv -f "$WORKDIR/taskmild.conf" "$CONFIG_DIR/taskmild.conf" 2>/dev/null || true
    fi
    if [ -f "$BINDIR/taskmild.pid" ] && [ ! -f "$LOCK_DIR/taskmild.pid" ]; then
        mv -f "$BINDIR/taskmild.pid" "$LOCK_DIR/taskmild.pid" 2>/dev/null || true
    fi
    if [ -f "$BINDIR/taskmild.lock" ] && [ ! -f "$LOCK_DIR/taskmild.lock" ]; then
        mv -f "$BINDIR/taskmild.lock" "$LOCK_DIR/taskmild.lock" 2>/dev/null || true
    fi
    if [ -f "$WORKDIR/run.log" ] && [ ! -f "$LOGS_DIR/run.log" ]; then
        mv -f "$WORKDIR/run.log" "$LOGS_DIR/run.log" 2>/dev/null || true
    fi
    for oldlog in "$WORKDIR"/run.log.* "$WORKDIR"/run_*.log; do
        [ -f "$oldlog" ] || continue
        base=$(basename "$oldlog")
        [ -f "$LOGS_DIR/$base" ] && continue
        mv -f "$oldlog" "$LOGS_DIR/$base" 2>/dev/null || true
    done
    if [ -f "$WORKDIR/purge_blacklist.cache" ] && [ ! -f "$LOCK_DIR/purge_blacklist.cache" ]; then
        mv -f "$WORKDIR/purge_blacklist.cache" "$LOCK_DIR/purge_blacklist.cache" 2>/dev/null || true
    fi
    if [ -f "$WORKDIR/purge_whitelist.cache" ] && [ ! -f "$LOCK_DIR/purge_whitelist.cache" ]; then
        mv -f "$WORKDIR/purge_whitelist.cache" "$LOCK_DIR/purge_whitelist.cache" 2>/dev/null || true
    fi
    if [ -f "$CONFIG_DIR/taskmild.conf" ]; then
        if [ ! -f "$CONFIG_DIR/Cleanup_Whitelist.txt" ]; then
            _old_wl=$(sed -n 's/^清理白名单=//p' "$CONFIG_DIR/taskmild.conf" 2>/dev/null | head -n1)
            if [ -n "$_old_wl" ]; then
                printf '# 从 taskmild.conf 迁移\n' > "$CONFIG_DIR/Cleanup_Whitelist.txt"
                echo "$_old_wl" | tr ',' '\n' | while IFS= read -r _line; do
                    _line=$(echo "$_line" | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')
                    [ -n "$_line" ] && printf '%s\n' "$_line" >> "$CONFIG_DIR/Cleanup_Whitelist.txt"
                done
                sed -i '/^清理白名单=/d' "$CONFIG_DIR/taskmild.conf" 2>/dev/null || true
            else
                printf '# 清理白名单 (一行一条规则)\n# 支持: /path /path/ /path/* com.app.pkg\n' > "$CONFIG_DIR/Cleanup_Whitelist.txt"
            fi
        fi
        if [ ! -f "$CONFIG_DIR/Cleanup_Blacklist.txt" ]; then
            _old_bl=$(sed -n 's/^清理黑名单=//p' "$CONFIG_DIR/taskmild.conf" 2>/dev/null | head -n1)
            if [ -n "$_old_bl" ]; then
                printf '# 从 taskmild.conf 迁移\n' > "$CONFIG_DIR/Cleanup_Blacklist.txt"
                echo "$_old_bl" | tr ',' '\n' | while IFS= read -r _line; do
                    _line=$(echo "$_line" | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')
                    [ -n "$_line" ] && printf '%s\n' "$_line" >> "$CONFIG_DIR/Cleanup_Blacklist.txt"
                done
                sed -i '/^清理黑名单=/d' "$CONFIG_DIR/taskmild.conf" 2>/dev/null || true
            else
                printf '# 清理黑名单 (一行一条规则)\n# 支持: /path /path/ /path/* pkg:com.app empty:/path gc:N\n' > "$CONFIG_DIR/Cleanup_Blacklist.txt"
            fi
        fi
    fi

    for old_file in license_agreed panic_flag stop_marker auth_fail_count crash_count crash_day thermal_mounts.list; do
        if [ -f "$WORKDIR/$old_file" ] && [ ! -f "$DATA_DIR/$old_file" ]; then
            mv -f "$WORKDIR/$old_file" "$DATA_DIR/$old_file" 2>/dev/null || true
        fi
    done
    if [ -f "$WORKDIR/auth_fail_count.lock" ] && [ ! -f "$DATA_DIR/auth_fail_count.lock" ]; then
        mv -f "$WORKDIR/auth_fail_count.lock" "$DATA_DIR/auth_fail_count.lock" 2>/dev/null || true
    fi
    if [ -f "$WORKDIR/thermal_bind.log" ] && [ ! -f "$LOGS_DIR/thermal_bind.log" ]; then
        mv -f "$WORKDIR/thermal_bind.log" "$LOGS_DIR/thermal_bind.log" 2>/dev/null || true
    fi
    if [ -f "$WORKDIR/stats.txt" ] && [ ! -f "$DATA_DIR/stats.txt" ]; then
        mv -f "$WORKDIR/stats.txt" "$DATA_DIR/stats.txt" 2>/dev/null || true
    fi
}
info "Migrating config paths..." "正在迁移配置路径..."
migrate_v944_paths
info "Config paths migrated" "配置路径迁移完成"

check_nandswap_support() {
    if [ -e /sys/block/zram0/hybridswap_core_enable ] && [ -f /product/bin/nandswap_tool ]; then
        if [ "$(echo "$KERNEL_VERSION" | cut -d'.' -f1)" -lt 6 ]; then
            if ! grep -q zram1 /proc/swaps 2>/dev/null; then
                blk_val=$(cat /sys/block/zram0/hybridswap_loop_device 2>/dev/null)
                if [ "$blk_val" != "chp" ]; then
                    return 0
                fi
            fi
        fi
    fi
    return 1
}

check_smartswap_support() {
    if [ -e /sys/block/zram0/smartswap_core_enable ] && [ -f /vendor/bin/smartzram_tool ]; then
        if [ "$(echo "$KERNEL_VERSION" | cut -d'.' -f1)" -lt 6 ]; then
            return 0
        fi
    fi
    return 1
}

check_zstd_support() {
    if [ -f /sys/block/zram0/comp_algorithm ]; then
        grep -q 'zstd' /sys/block/zram0/comp_algorithm 2>/dev/null && return 0
    fi
    grep -q 'zstd' /proc/crypto 2>/dev/null && return 0
    return 1
}

check_writeback_support() {
    if [ -f /sys/block/zram0/backing_dev ] && [ -f /sys/block/zram0/writeback ]; then
        kv=$(echo "$KERNEL_VERSION" | cut -d'.' -f1)
        if [ "$kv" -ge 5 ]; then
            return 0
        fi
    fi
    return 1
}

detect_comp_algorithm() {
    if [ -f /sys/block/zram0/comp_algorithm ]; then
        avail=$(cat /sys/block/zram0/comp_algorithm 2>/dev/null)
        for alg in zstd lz4 lzo-rle lzo; do
            if echo "$avail" | grep -q "$alg"; then
                echo "$alg"
                return
            fi
        done
    fi
    echo "lz4"
}

compute_zram_size() {
    _ram_mb=$((MEM_TOTAL_KB / 1024))
    _has_ns=0

    if check_nandswap_support || check_smartswap_support; then
        _multiplier=10
        _has_ns=1
    elif [ "$MEM_TOTAL_GB" -ge 8 ] && [ "$KERNEL_VERSION_1" -ge 6 ]; then
        _multiplier=10
    elif [ "$KERNEL_VERSION_1" -ge 6 ]; then
        _multiplier=8
    elif check_zstd_support; then
        _multiplier=7
    else
        _multiplier=10
    fi

    ZramSize=$((_ram_mb * _multiplier / 10))
    ZramMultiplier=$_multiplier

    ZramSize=$(( (ZramSize + 127) / 256 * 256 ))

    [ "$ZramSize" -lt 512 ] && ZramSize=512

    if [ "$_has_ns" = "1" ] && check_writeback_support; then
        AutoWriteback="true"
    else
        AutoWriteback="false"
    fi

    AutoCompAlgorithm=$(detect_comp_algorithm)

    _cur_swappiness=$(cat /proc/sys/vm/swappiness 2>/dev/null || echo 100)
    if echo 150 > /proc/sys/vm/swappiness 2>/dev/null; then
        _max1=$(cat /proc/sys/vm/swappiness 2>/dev/null || echo 100)
        if echo 200 > /proc/sys/vm/swappiness 2>/dev/null; then
            _max2=$(cat /proc/sys/vm/swappiness 2>/dev/null || echo $_max1)
        else
            _max2=$_max1
        fi
        echo "$_cur_swappiness" > /proc/sys/vm/swappiness 2>/dev/null
    else
        _max2=$_cur_swappiness
    fi
    if [ "$_max2" -gt 100 ]; then
        AutoSwappiness=125
    else
        AutoSwappiness=100
    fi

    if [ "$MEM_TOTAL_GB" -le 4 ]; then
        AutoExtraFreeKbytes=4096
    elif [ "$MEM_TOTAL_GB" -le 8 ]; then
        AutoExtraFreeKbytes=8192
    else
        AutoExtraFreeKbytes=16384
    fi

    if [ "$MEM_TOTAL_GB" -le 4 ]; then
        AutoWatermark=15
    elif [ "$MEM_TOTAL_GB" -le 8 ]; then
        AutoWatermark=20
    else
        AutoWatermark=40
    fi
}

is_xiaomi() {
    [ -n "$(getprop ro.miui.ui.version.name 2>/dev/null)" ] && return 0
    _brand=$(getprop ro.product.brand 2>/dev/null | tr '[:upper:]' '[:lower:]')
    [ "$_brand" = "xiaomi" ] && return 0
    _mfr=$(getprop ro.product.manufacturer 2>/dev/null | tr '[:upper:]' '[:lower:]')
    [ "$_mfr" = "xiaomi" ] && return 0
    return 1
}

is_oppo() {
    _brand=$(getprop ro.product.brand 2>/dev/null | tr '[:upper:]' '[:lower:]')
    case "$_brand" in
        oppo|oneplus|realme) return 0 ;;
    esac
    [ -n "$(getprop persist.sys.oplus.confirm 2>/dev/null)" ] && return 0
    [ -d /sys/kernel/mm/athena ] && return 0
    return 1
}

is_qualcomm_kona() {
    case "$PLATFORM" in
        kona|lahaina|shima|taro|cape|parrot|diwali|ukee) return 0 ;;
    esac
    case "$SOC" in
        SM8250|SM8350|SM8450|SM8475|SM8550|SM8650) return 0 ;;
    esac
    return 1
}

is_mtk_new() {
    case "$PLATFORM" in
        mt6*) return 0 ;;
    esac
    case "$SOC" in
        MT6*) return 0 ;;
    esac
    if [ "$KERNEL_VERSION_1" -ge 5 ] && [ -f /proc/psi ]; then
        _mfr=$(getprop ro.hardware 2>/dev/null | tr '[:upper:]' '[:lower:]')
        case "$_mfr" in
            mt6*) return 0 ;;
        esac
    fi
    return 1
}

is_xiaomi_8gen1() {
    is_xiaomi || return 1
    case "$SOC" in
        SM8450|SM8475) return 0 ;;
    esac
    case "$PLATFORM" in
        taro|ukee|diwali) return 0 ;;
    esac
    return 1
}

drain_volume_events() {
    timeout 0.2 getevent -lc 8 2>/dev/null | grep -E "KEY_VOLUME(UP|DOWN)" >/dev/null 2>&1 || true
}

wait_volume_key() {
    timeout_secs="$1"
    start_time=$(date +%s)
    while true; do
        now_time=$(date +%s)
        if [ "$((now_time - start_time))" -gt "$timeout_secs" ]; then
            printf '%s\n' "timeout"
            return 0
        fi
        event=$(timeout 1 getevent -c 1 2>/dev/null)
        case "$event" in
            *0073*00000001*) printf '%s\n' "up"; return 0 ;;
            *0072*00000001*) printf '%s\n' "down"; return 0 ;;
        esac
    done
}

update_conf_auto_values() {
    _conf="$1"
    [ -f "$_conf" ] || return

    if [ "$USER_SWAP_ENABLE" = "off" ]; then
        return
    fi

    ui_print "    zram_size=${ZramSize}MB | comp_algorithm=${AutoCompAlgorithm}"
    ui_print "    swappiness=${AutoSwappiness} | writeback=${AutoWriteback}"
    ui_print "    extra_free_kbytes=${AutoExtraFreeKbytes} | watermark=${AutoWatermark}"

    sed -i "s|^zram_size=.*|zram_size=${ZramSize}|" "$_conf"
    sed -i "s|^comp_algorithm=.*|comp_algorithm=${AutoCompAlgorithm}|" "$_conf"
    sed -i "s|^swappiness=.*|swappiness=${AutoSwappiness}|" "$_conf"
    sed -i "s|^zram_writeback=.*|zram_writeback=${AutoWriteback}|" "$_conf"
    sed -i "s|^extra_free_kbytes=.*|extra_free_kbytes=${AutoExtraFreeKbytes}|" "$_conf"
    sed -i "s|^watermark_scale_factor=.*|watermark_scale_factor=${AutoWatermark}|" "$_conf"
}

USER_SWAP_ENABLE="on"
USER_SWAP_MODE="zram_only"
USER_SWAP_FILE_SIZE=""
USER_LMK_SUPPRESS="off"
USER_THERMAL_ENABLE="off"

ask_swap_preference() {
    ui_print " "
    ui_print "===================="
    if [ "$language" = "en" ]; then
        ui_print " Swap / ZRAM Setup"
        ui_print "===================="
        ui_print " Enable Swap/ZRAM optimization?"
        ui_print " VOL UP:   Enable (recommended)"
        ui_print " VOL DOWN: Disable (process mgmt only)"
        ui_print " ${CHOICE_TIMEOUT_SECS}s timeout = Enable"
    else
        ui_print " Swap / ZRAM 配置"
        ui_print "===================="
        ui_print " 是否启用 Swap/ZRAM 内存优化？"
        ui_print " 音量上键: 启用 (推荐)"
        ui_print " 音量下键: 禁用 (仅进程管理)"
        ui_print " ${CHOICE_TIMEOUT_SECS}秒无操作 = 启用"
    fi
    ui_print "===================="
    ui_print " "

    drain_volume_events
    choice=$(wait_volume_key "$CHOICE_TIMEOUT_SECS")
    case "$choice" in
        down)
            USER_SWAP_ENABLE="off"
            USER_SWAP_MODE="swap_off"
            info "Swap: DISABLED" "Swap: 已禁用"
            return
            ;;
        up|timeout|*)
            USER_SWAP_ENABLE="on"
            info "Swap: ENABLED" "Swap: 已启用"
            ;;
    esac

    sleep 0.3

    ui_print " "
    ui_print "===================="
    if [ "$language" = "en" ]; then
        ui_print " Swap Mode"
        ui_print "===================="
        ui_print " VOL UP:   ZRAM only (recommended)"
        ui_print "           Compressed RAM, no disk usage"
        ui_print " VOL DOWN: ZRAM + Swap file"
        ui_print "           Extra swap on /data (8GB+ RAM)"
        ui_print " ${CHOICE_TIMEOUT_SECS}s timeout = ZRAM only"
    else
        ui_print " Swap 模式"
        ui_print "===================="
        ui_print " 音量上键: 仅 ZRAM (推荐)"
        ui_print "           压缩内存交换，不占磁盘"
        ui_print " 音量下键: ZRAM + Swap 文件"
        ui_print "           额外 swap 文件 (适合 8GB+ 内存)"
        ui_print " ${CHOICE_TIMEOUT_SECS}秒无操作 = 仅 ZRAM"
    fi
    ui_print "===================="
    ui_print " "

    drain_volume_events
    choice=$(wait_volume_key "$CHOICE_TIMEOUT_SECS")
    case "$choice" in
        down)
            USER_SWAP_MODE="zram_and_file"
            _swap_mb=$((MEM_TOTAL_KB / 1024 / 2))
            _swap_mb=$(( (_swap_mb + 127) / 256 * 256 ))
            [ "$_swap_mb" -lt 1024 ] && _swap_mb=1024
            USER_SWAP_FILE_SIZE="$_swap_mb"
            info "Mode: ZRAM + Swap ${USER_SWAP_FILE_SIZE}MB" "模式: ZRAM + Swap ${USER_SWAP_FILE_SIZE}MB"
            ;;
        up|timeout|*)
            USER_SWAP_MODE="zram_only"
            info "Mode: ZRAM only" "模式: 仅 ZRAM"
            ;;
    esac
}

ask_lmk_preference() {
    ui_print " "
    ui_print "===================="
    if [ "$language" = "en" ]; then
        ui_print " LMK Suppression"
        ui_print "===================="
        ui_print " Suppress system LMK (Low Memory Killer)?"
        ui_print " This raises minfree thresholds and disables DAMON."
        ui_print " lmkd remains as safety net."
        ui_print " VOL UP:   Enable LMK suppression"
        ui_print " VOL DOWN: Keep default (recommended)"
        ui_print " ${CHOICE_TIMEOUT_SECS}s timeout = Keep default"
    else
        ui_print " 抑制系统 LMK 机制"
        ui_print "===================="
        ui_print " 是否抑制系统 LMK (低内存杀手)?"
        ui_print " 将拉高minfree阈值、禁用DAMON等。"
        ui_print " lmkd 仍作为安全网运行。"
        ui_print " 音量上键: 启用抑制"
        ui_print " 音量下键: 保持默认 (推荐)"
        ui_print " ${CHOICE_TIMEOUT_SECS}秒无操作 = 保持默认"
    fi
    ui_print "===================="
    ui_print " "

    drain_volume_events
    choice=$(wait_volume_key "$CHOICE_TIMEOUT_SECS")
    case "$choice" in
        up)
            USER_LMK_SUPPRESS="on"
            info "LMK suppression: ENABLED" "LMK 抑制: 已启用"
            ;;
        down|timeout|*)
            USER_LMK_SUPPRESS="off"
            info "LMK suppression: DISABLED" "LMK 抑制: 未启用"
            ;;
    esac
}

ask_thermal_preference() {
    if [ "$THERMAL_STAGED" -eq 0 ] 2>/dev/null; then
        USER_THERMAL_ENABLE="off"
        return
    fi

    ui_print " "
    ui_print "===================="
    if [ "$language" = "en" ]; then
        ui_print " Thermal Override"
        ui_print "===================="
        ui_print " Feature credit: 酷安@御坂Thepoor"
        ui_print "   (移除温控, authorized merge)"
        ui_print " Mount 457 empty files over system thermal configs"
        ui_print " to block thermal throttling (perf boost, more heat)."
        ui_print " VOL UP:   Enable thermal override"
        ui_print " VOL DOWN: Keep system thermal (default, recommended)"
        ui_print " ${CHOICE_TIMEOUT_SECS}s timeout = Keep system thermal"
    else
        ui_print " 温控屏蔽"
        ui_print "===================="
        ui_print " 温控屏蔽功能来自: 酷安@御坂Thepoor"
        ui_print "   (移除温控【正式版】, 已授权融合)"
        ui_print " 挂载 457 个空文件覆盖系统温控配置, 屏蔽温控降频"
        ui_print " (释放性能, 但会增加发热, 谨慎选择)"
        ui_print " 音量上键: 启用温控屏蔽"
        ui_print " 音量下键: 保留系统温控 (默认, 推荐)"
        ui_print " ${CHOICE_TIMEOUT_SECS}秒无操作 = 保留系统温控"
    fi
    ui_print "===================="
    ui_print " "

    drain_volume_events
    choice=$(wait_volume_key "$CHOICE_TIMEOUT_SECS")
    case "$choice" in
        up)
            USER_THERMAL_ENABLE="on"
            info "Thermal override: ENABLED" "温控屏蔽: 已启用"
            ;;
        down|timeout|*)
            USER_THERMAL_ENABLE="off"
            info "Thermal override: DISABLED (default)" "温控屏蔽: 未启用 (默认)"
            ;;
    esac
}

ask_preferences_and_compute() {
    ask_swap_preference
    ask_lmk_preference
    ask_thermal_preference

    if [ "$USER_SWAP_ENABLE" = "on" ]; then
        compute_zram_size

        case "$ZramMultiplier" in
            10) _mult_display="1.0x" ;;
            8)  _mult_display="0.8x (新内核)" ;;
            7)  _mult_display="0.7x (zstd)" ;;
            *)  _mult_display="${ZramMultiplier}x" ;;
        esac

        info "ZRAM: ${ZramSize}MB (${MEM_TOTAL_GB}GB × ${_mult_display})" "ZRAM: ${ZramSize}MB (${MEM_TOTAL_GB}GB × ${_mult_display})"
        info "Compress: ${AutoCompAlgorithm} | Swappiness: ${AutoSwappiness}" "压缩: ${AutoCompAlgorithm} | Swappiness: ${AutoSwappiness}"
        info "Writeback: ${AutoWriteback} | ExtraFree: ${AutoExtraFreeKbytes}KB | Watermark: ${AutoWatermark}" "Writeback: ${AutoWriteback} | ExtraFree: ${AutoExtraFreeKbytes}KB | Watermark: ${AutoWatermark}"
    fi
}

apply_swap_choice() {
    _conf="$1"
    [ -f "$_conf" ] || return

    sed -i "s|^swap_enable=.*|swap_enable=${USER_SWAP_ENABLE}|" "$_conf"

    if [ "$USER_SWAP_ENABLE" = "on" ]; then
        if [ "$USER_SWAP_MODE" = "zram_only" ]; then
            sed -i "s|^zram=.*|zram=true|" "$_conf"
            sed -i "s|^swap=.*|swap=false|" "$_conf"
            sed -i "s|^swap_size=.*|swap_size=|" "$_conf"
        elif [ "$USER_SWAP_MODE" = "zram_and_file" ]; then
            sed -i "s|^zram=.*|zram=true|" "$_conf"
            sed -i "s|^swap=.*|swap=true|" "$_conf"
            sed -i "s|^swap_size=.*|swap_size=${USER_SWAP_FILE_SIZE}|" "$_conf"
        fi
    else
        sed -i "s|^zram=.*|zram=false|" "$_conf"
        sed -i "s|^swap=.*|swap=false|" "$_conf"
        sed -i "s|^swap_size=.*|swap_size=|" "$_conf"
    fi

    ui_print "    swap_enable=${USER_SWAP_ENABLE}"
    if [ "$USER_SWAP_ENABLE" = "on" ]; then
        if [ "$USER_SWAP_MODE" = "zram_only" ]; then
            info "    zram=true | swap=false" "    zram=true | swap=false (仅 ZRAM)"
        else
            info "    zram=true | swap=true (${USER_SWAP_FILE_SIZE}MB)" "    zram=true | swap=true (ZRAM + ${USER_SWAP_FILE_SIZE}MB)"
        fi
    else
        info "    zram=false | swap=false" "    zram=false | swap=false (已禁用)"
    fi

    sed -i "s|^抑制LMK=.*|抑制LMK=${USER_LMK_SUPPRESS}|" "$_conf"
}

apply_thermal_choice() {
    _conf="$1"
    [ -f "$_conf" ] || return

    sed -i "s|^thermal_enable=.*|thermal_enable=${USER_THERMAL_ENABLE}|" "$_conf"

    _toggle_script="$MODPATH/scripts/tools.thermal-toggle.sh"
    if [ -x "$_toggle_script" ]; then
        "$_toggle_script" --apply >/dev/null 2>&1 || true
    fi

    ui_print "    thermal_enable=${USER_THERMAL_ENABLE}"
    if [ "$USER_THERMAL_ENABLE" = "on" ]; then
        info "    Thermal: override mounted (reboot to take effect)" "    温控屏蔽: 已挂载 (重启生效)"
    else
        info "    Thermal: override unmounted (reboot to take effect)" "    温控屏蔽: 未挂载 (重启生效)"
    fi
}

load_swap_state_from_conf() {
    _conf="$1"
    [ -f "$_conf" ] || return 0

    _zram_val=$(grep '^zram=' "$_conf" 2>/dev/null | head -n1 | cut -d= -f2)
    _swap_val=$(grep '^swap=' "$_conf" 2>/dev/null | head -n1 | cut -d= -f2)
    _swap_size_val=$(grep '^swap_size=' "$_conf" 2>/dev/null | head -n1 | cut -d= -f2)
    if [ "$_swap_val" = "true" ] && [ -n "$_swap_size_val" ]; then
        USER_SWAP_MODE="zram_and_file"
        USER_SWAP_FILE_SIZE="$_swap_size_val"
    else
        USER_SWAP_MODE="zram_only"
        USER_SWAP_FILE_SIZE=""
    fi

    ZramSize=$(grep '^zram_size=' "$_conf" 2>/dev/null | head -n1 | cut -d= -f2)
    [ -z "$ZramSize" ] && ZramSize="auto"
    AutoCompAlgorithm=$(grep '^comp_algorithm=' "$_conf" 2>/dev/null | head -n1 | cut -d= -f2)
    [ -z "$AutoCompAlgorithm" ] && AutoCompAlgorithm="auto"
    AutoSwappiness=$(grep '^swappiness=' "$_conf" 2>/dev/null | head -n1 | cut -d= -f2)
    [ -z "$AutoSwappiness" ] && AutoSwappiness="auto"
    AutoWriteback=$(grep '^zram_writeback=' "$_conf" 2>/dev/null | head -n1 | cut -d= -f2)
    [ -z "$AutoWriteback" ] && AutoWriteback="false"
}

sync_config_keys() {
    _user_conf="$1"
    _module_conf="$2"
    [ -f "$_user_conf" ] || return 0
    [ -f "$_module_conf" ] || return 0

    _tmp_filtered="$(mktemp 2>/dev/null)" || _tmp_filtered="/data/local/tmp/tm_filter_$$.tmp"
    _tmp_added="$(mktemp 2>/dev/null)" || _tmp_added="/data/local/tmp/tm_added_$$.tmp"
    _added_list="$(mktemp 2>/dev/null)" || _added_list="/data/local/tmp/tm_alist_$$.tmp"
    _removed_list="$(mktemp 2>/dev/null)" || _removed_list="/data/local/tmp/tm_rlist_$$.tmp"

    awk -v MODULE_CONF="$_module_conf" -v REMOVED_LIST="$_removed_list" '
        BEGIN {
            while ((getline line < MODULE_CONF) > 0) {
                if (line ~ /^[[:space:]]*#/) continue
                if (line ~ /^[[:space:]]*$/) continue
                eq = index(line, "=")
                if (eq > 0) {
                    k = substr(line, 1, eq - 1)
                    sub(/^[[:space:]]+/, "", k)
                    sub(/[[:space:]]+$/, "", k)
                    module_keys[k] = 1
                }
            }
            close(MODULE_CONF)
            cmt_buf = ""
            has_cmt = 0
        }
        {
            line = $0
            if (line ~ /^[[:space:]]*#/) {
                if (has_cmt) cmt_buf = cmt_buf "\n"
                cmt_buf = cmt_buf line
                has_cmt = 1
                next
            }
            if (line ~ /^[[:space:]]*$/) {
                if (has_cmt) {
                    print cmt_buf
                    cmt_buf = ""
                    has_cmt = 0
                }
                print ""
                next
            }
            eq = index(line, "=")
            if (eq > 0) {
                k = substr(line, 1, eq - 1)
                sub(/^[[:space:]]+/, "", k)
                sub(/[[:space:]]+$/, "", k)
                if (k in module_keys) {
                    if (has_cmt) { print cmt_buf; cmt_buf = ""; has_cmt = 0 }
                    print line
                } else {
                    print k > REMOVED_LIST
                    cmt_buf = ""
                    has_cmt = 0
                }
            } else {
                if (has_cmt) { print cmt_buf; cmt_buf = ""; has_cmt = 0 }
                print line
            }
        }
        END {
            if (has_cmt) print cmt_buf
        }
    ' "$_user_conf" > "$_tmp_filtered"

    awk -v FILTERED="$_tmp_filtered" -v ADDED_LIST="$_added_list" '
        BEGIN {
            while ((getline line < FILTERED) > 0) {
                if (line ~ /^[[:space:]]*#/) continue
                if (line ~ /^[[:space:]]*$/) continue
                eq = index(line, "=")
                if (eq > 0) {
                    k = substr(line, 1, eq - 1)
                    sub(/^[[:space:]]+/, "", k)
                    sub(/[[:space:]]+$/, "", k)
                    user_keys[k] = 1
                }
            }
            close(FILTERED)
            cmt_buf = ""
            has_cmt = 0
            added_any = 0
        }
        {
            line = $0
            if (line ~ /^[[:space:]]*#/) {
                if (has_cmt) cmt_buf = cmt_buf "\n"
                cmt_buf = cmt_buf line
                has_cmt = 1
                next
            }
            if (line ~ /^[[:space:]]*$/) {
                if (has_cmt) cmt_buf = cmt_buf "\n"
                cmt_buf = cmt_buf ""
                next
            }
            eq = index(line, "=")
            if (eq > 0) {
                k = substr(line, 1, eq - 1)
                sub(/^[[:space:]]+/, "", k)
                sub(/[[:space:]]+$/, "", k)
                if (!(k in user_keys)) {
                    if (added_any) print ""
                    if (has_cmt) { print cmt_buf; cmt_buf = ""; has_cmt = 0 }
                    else { print "" }
                    print line
                    print k > ADDED_LIST
                    added_any = 1
                }
                cmt_buf = ""
                has_cmt = 0
            } else {
                cmt_buf = ""
                has_cmt = 0
            }
        }
    ' "$_module_conf" > "$_tmp_added"

    _added_count=0
    _removed_count=0
    [ -s "$_added_list" ] && _added_count=$(wc -l < "$_added_list" | tr -d ' ')
    [ -s "$_removed_list" ] && _removed_count=$(wc -l < "$_removed_list" | tr -d ' ')

    if [ "$_added_count" -eq 0 ] && [ "$_removed_count" -eq 0 ]; then
        info "Config keys consistent, no changes" "配置项一致, 无需同步"
        rm -f "$_tmp_filtered" "$_tmp_added" "$_added_list" "$_removed_list"
        return 0
    fi

    cp -af "$_tmp_filtered" "$_user_conf"
    if [ -s "$_tmp_added" ]; then
        _last_byte=$(tail -c1 "$_user_conf" 2>/dev/null | od -An -tx1 2>/dev/null | tr -d ' \n')
        [ "$_last_byte" != "0a" ] && printf '\n' >> "$_user_conf"
        printf '\n# ===== v%s 自动同步新增配置项 =====\n' "$NEW_VERSION" >> "$_user_conf"
        cat "$_tmp_added" >> "$_user_conf"
    fi

    ui_print " "
    ui_print "===================="
    if [ "$_added_count" -gt 0 ]; then
        info "Added $_added_count new config keys:" "新增 $_added_count 个配置项:"
        while IFS= read -r _k; do
            [ -n "$_k" ] && ui_print "  + $_k"
        done < "$_added_list"
    fi
    if [ "$_removed_count" -gt 0 ]; then
        info "Removed $_removed_count obsolete config keys:" "删除 $_removed_count 个废弃配置项:"
        while IFS= read -r _k; do
            [ -n "$_k" ] && ui_print "  - $_k"
        done < "$_removed_list"
    fi
    ui_print "===================="
    ui_print " "

    info "Config synced: +$_added_count / -$_removed_count" "配置同步完成: +$_added_count / -$_removed_count"

    rm -f "$_tmp_filtered" "$_tmp_added" "$_added_list" "$_removed_list"
    return 0
}

if [ ! -f "$CONF" ]; then
    ask_preferences_and_compute
    cp -af "$MODULE_CONF" "$CONF"
    update_conf_auto_values "$CONF"
    apply_swap_choice "$CONF"
    apply_thermal_choice "$CONF"
else
    USER_SWAP_ENABLE=$(grep '^swap_enable=' "$CONF" 2>/dev/null | cut -d= -f2)
    USER_SWAP_ENABLE="${USER_SWAP_ENABLE:-on}"
    USER_THERMAL_ENABLE=$(grep '^thermal_enable=' "$CONF" 2>/dev/null | cut -d= -f2)
    USER_THERMAL_ENABLE="${USER_THERMAL_ENABLE:-off}"
    sync_config_keys "$CONF" "$MODULE_CONF"
    if [ "$USER_SWAP_ENABLE" = "on" ]; then
        load_swap_state_from_conf "$CONF"
    fi
    apply_thermal_choice "$CONF"
fi

select_system_prop() {
    if is_oppo; then
        if [ -f "$MODPATH/system.oplus.prop" ]; then
            cp -af "$MODPATH/system.oplus.prop" "$MODPATH/system.prop"
            info "Using OPPO/OPlus props" "使用 OPPO/OPlus 系统属性"
        fi
    elif is_xiaomi; then
        if [ -f "$MODPATH/system.mi.prop" ]; then
            cp -af "$MODPATH/system.mi.prop" "$MODPATH/system.prop"
            info "Using Xiaomi props" "使用小米系统属性"
        fi
    elif is_qualcomm_kona; then
        if [ -f "$MODPATH/system.qti.prop" ]; then
            cp -af "$MODPATH/system.qti.prop" "$MODPATH/system.prop"
            info "Using Qualcomm props" "使用 Qualcomm 系统属性"
        fi
    fi
}

apply_lmk_props() {
    _prop_file="$MODPATH/system.prop"

    if is_xiaomi_8gen1; then
        echo "persist.sys.minfree_6g=16384,20480,32768,131072,262144,384000" >> "$_prop_file"
        echo "persist.sys.minfree_8g=16384,20480,32768,131072,384000,524288" >> "$_prop_file"
        echo "persist.sys.minfree_12g=16384,20480,131072,384000,524288,819200" >> "$_prop_file"
        info "Xiaomi 8GEN1 LMK props set" "小米 8GEN1 LMK 属性已设置"
    elif is_oppo; then
        echo "persist.sys.oplus.memory.kill_policy=1" >> "$_prop_file"
        echo "persist.sys.oplus.process_manager.bg_limit=64" >> "$_prop_file"
        info "OPPO LMK props set" "OPPO LMK 属性已设置"
    elif is_qualcomm_kona; then
        echo "persist.vendor.qcom.memory.enable_oom_adj=true" >> "$_prop_file"
        echo "ro.qcom.mem.bg_apps_limit=64" >> "$_prop_file"
        info "Qualcomm Kona LMK props set" "Qualcomm Kona LMK 属性已设置"
    fi

    if ! grep -q '^ro.config.low_ram=' "$_prop_file" 2>/dev/null; then
        echo "ro.config.low_ram=false" >> "$_prop_file"
    fi
    if ! grep -q '^ro.sys.fw.bg_apps_limit=' "$_prop_file" 2>/dev/null; then
        echo "ro.sys.fw.bg_apps_limit=64" >> "$_prop_file"
    fi
}

patch_perfconfigstore() {
    _pcf_dirs="/data/system /data/system_ce/0"
    _pcf_found=0

    for _pcf_dir in $_pcf_dirs; do
        _pcf_xml="$_pcf_dir/perfconfigstore.xml"
        [ -f "$_pcf_xml" ] || continue
        _pcf_found=1

        cp -af "$_pcf_xml" "${_pcf_xml}.tm_bak" 2>/dev/null || true

        sed -i 's|value="lmk_adj"[^>]*|value="0,100,200,300,500,900"|g' "$_pcf_xml" 2>/dev/null || true
        sed -i 's|value="lmk_minfree"[^>]*|value="18432,23040,27648,32256,36864,46080"|g' "$_pcf_xml" 2>/dev/null || true
        sed -i 's|value="batch_kill"[^>]*|value="true"|g' "$_pcf_xml" 2>/dev/null || true
        sed -i 's|value="trim_enabled"[^>]*|value="true"|g' "$_pcf_xml" 2>/dev/null || true
        sed -i 's|value="kill_policy"[^>]*|value="1"|g' "$_pcf_xml" 2>/dev/null || true
    done

    if is_oppo; then
        for _nirvana in /data/oplus/nirvana/perfconfigstore.xml /data/oppo/nirvana/perfconfigstore.xml; do
            [ -f "$_nirvana" ] || continue
            cp -af "$_nirvana" "${_nirvana}.tm_bak" 2>/dev/null || true
            sed -i 's|value="kill_policy"[^>]*|value="1"|g' "$_nirvana" 2>/dev/null || true
            sed -i 's|value="bg_limit"[^>]*|value="64"|g' "$_nirvana" 2>/dev/null || true
        done
    fi
}

patch_oppo_configs() {
    is_oppo || return

    if [ -d "$MODPATH/athena" ]; then
        if command -v content >/dev/null 2>&1; then
            if [ -f "$MODPATH/scripts/tools.romupdate.sh" ]; then
                MODDIR="$MODPATH/scripts"
                export MODDIR
                . "$MODPATH/scripts/tools.sh"
                . "$MODPATH/scripts/tools.romupdate.sh"
                patch_update_list 2>/dev/null || true
            fi
        fi
    fi

    _rom_db="/data/user_de/0/com.oplus.romupdate/databases/rom_update.db"
    if [ -f "$_rom_db" ]; then
        cp -pf "$_rom_db" "${_rom_db}.tm_bak" 2>/dev/null || true
    fi
}

select_system_prop
apply_lmk_props

if [ "$USER_SWAP_ENABLE" = "on" ]; then
    patch_oppo_configs
    patch_perfconfigstore

    if is_mtk_new; then
        setprop persist.vendor.psi.enable true 2>/dev/null || true
        info "MTK: PSI enabled" "MTK: PSI 已启用"
    fi

    if is_xiaomi; then
        if is_xiaomi_8gen1; then
            info "Xiaomi 8GEN1: Special params set" "小米 8GEN1: 特殊参数已配置"
        fi
    fi
fi

if is_mtk_new; then
    if ! grep -q '^ro.vendor.psi.enable=' "$MODPATH/system.prop" 2>/dev/null; then
        echo "ro.vendor.psi.enable=true" >> "$MODPATH/system.prop"
    fi
fi

if [ "$USER_SWAP_ENABLE" = "off" ]; then
    if [ -f "$MODPATH/system.prop" ]; then
        mv -f "$MODPATH/system.prop" "$MODPATH/system.prop.tm"
    fi
else
    if [ -f "$MODPATH/system.prop.tm" ] && [ ! -f "$MODPATH/system.prop" ]; then
        mv -f "$MODPATH/system.prop.tm" "$MODPATH/system.prop"
    fi
fi

rm -f "$WORKDIR/run.log" "$WORKDIR/run.log.1" "$BINDIR/taskmild.pid" 2>/dev/null || true
if [ -f "$WORKDIR/lock" ]; then
    rm -f "$WORKDIR/lock" 2>/dev/null || true
fi
mkdir -p "$CONFIG_DIR" "$LOCK_DIR" "$LOGS_DIR" "$BINDIR"
touch "$LOGS_DIR/run.log"

info "Setting permissions..." "正在设置文件权限..."
chmod 0755 "$MODPATH/service.sh" "$MODPATH/action.sh" "$MODPATH/uninstall.sh"
chmod 0644 "$MODPATH/module.prop"
chmod 0755 "$BIN"
chmod 0644 "$CONF" "$LOGS_DIR/run.log"
chmod 0644 "$CONFIG_DIR/Cleanup_Whitelist.txt" "$CONFIG_DIR/Cleanup_Blacklist.txt" 2>/dev/null || true

if [ -d "$MODPATH/scripts" ]; then
    chmod 0755 "$MODPATH/scripts"
    find "$MODPATH/scripts" -type f -name '*.sh' -exec chmod 0755 {} \; 2>/dev/null || true
fi
if [ -d "$MODPATH/specific" ]; then
    find "$MODPATH/specific" -type d -exec chmod 0755 {} \; 2>/dev/null || true
    find "$MODPATH/specific" -type f -name '*.sh' -exec chmod 0755 {} \; 2>/dev/null || true
fi
if [ -d "$MODPATH/webroot" ]; then
    chmod 0755 "$MODPATH/webroot"
    find "$MODPATH/webroot" -type f -exec chmod 0644 {} \; 2>/dev/null || true
fi
info "Permissions set" "文件权限设置完成"

KSUWEBUI_INSTALLED=0
install_ksuwebui() {
    _apk_name="KsuWebUI-1.0-34-release.apk"
    _apk="$MODPATH/payload/$_apk_name"
    _pkg="io.github.a13e300.ksuwebui"

    if [ ! -f "$_apk" ]; then
        info "KsuWebUI APK not bundled, skip" "未内置 KsuWebUI APK, 跳过"
        return 1
    fi

    if ! command -v pm >/dev/null 2>&1; then
        info "pm unavailable, skip KsuWebUI" "pm 命令不可用, 跳过 KsuWebUI"
        return 1
    fi

    _already=0
    pm list packages 2>/dev/null | grep -q "package:$_pkg$" && _already=1

    if [ "$_already" = "1" ]; then
        info "KsuWebUI already installed, upgrading..." "KsuWebUI 已安装, 升级中..."
    else
        info "Installing KsuWebUI v1.0.34..." "正在安装 KsuWebUI v1.0.34..."
    fi

    if pm install -r "$_apk" >/dev/null 2>&1; then
        if pm list packages 2>/dev/null | grep -q "package:$_pkg$"; then
            KSUWEBUI_INSTALLED=1
            if [ "$_already" = "1" ]; then
                info "KsuWebUI upgraded to v1.0.34" "KsuWebUI 已升级至 v1.0.34"
            else
                info "KsuWebUI v1.0.34 installed" "KsuWebUI v1.0.34 已安装"
            fi
            return 0
        fi
    fi
    info "KsuWebUI install failed (non-fatal)" "KsuWebUI 安装失败 (非致命, 可手动安装)"
    return 1
}

if [ "$ROOT_MANAGER" = "magisk" ]; then
    install_ksuwebui
fi

ui_print " "
ui_print "===================="
ui_print " TaskMild v${NEW_VERSION}"
info " Installed successfully" " 安装完成"
info " Author: linjoin (酷安@嘿_嘿_)" " 作者: linjoin (酷安@嘿_嘿_)"
ui_print "===================="
if [ "$USER_SWAP_ENABLE" = "on" ]; then
    if [ "$USER_SWAP_MODE" = "zram_only" ]; then
        info " Swap: ZRAM ${ZramSize}MB (${AutoCompAlgorithm})" " Swap: ZRAM ${ZramSize}MB (${AutoCompAlgorithm})"
    else
        info " Swap: ZRAM ${ZramSize}MB + File ${USER_SWAP_FILE_SIZE}MB" " Swap: ZRAM ${ZramSize}MB + 文件 ${USER_SWAP_FILE_SIZE}MB"
    fi
    info " Swappiness: ${AutoSwappiness} | Writeback: ${AutoWriteback}" " Swappiness: ${AutoSwappiness} | Writeback: ${AutoWriteback}"
else
    info " Swap: Disabled (process mgmt only)" " Swap: 已禁用 (仅进程管理)"
fi
if [ "$THERMAL_STAGED" -gt 0 ] 2>/dev/null; then
    if [ "$USER_THERMAL_ENABLE" = "on" ]; then
        info " Thermal: ENABLED (reboot to mount, check in WebUI)" " 温控屏蔽: 已启用 (重启挂载, 可在 WebUI 自检/切换)"
    else
        info " Thermal: DISABLED (toggle in WebUI anytime)" " 温控屏蔽: 未启用 (可随时在 WebUI 切换, 无需重刷)"
    fi
else
    info " Thermal: no override bundled" " 温控屏蔽: 未内置"
fi

if [ "$ROOT_MANAGER" = "magisk" ]; then
    if [ "$KSUWEBUI_INSTALLED" = "1" ]; then
        info " WebUI: Open KsuWebUI app after reboot" " WebUI: 重启后打开 KsuWebUI 应用"
    else
        info " WebUI: Install KsuWebUI to access web UI" " WebUI: 需安装 KsuWebUI 才能访问网页面板"
    fi
elif [ "$ROOT_MANAGER" = "ksu" ] || [ "$ROOT_MANAGER" = "apatch" ]; then
    info " WebUI: Use manager app -> Module WebUI" " WebUI: 在管理器应用 -> 模块 WebUI 中打开"
fi

info " Reboot to take effect" " 请重启设备生效"
ui_print "===================="

set +u
